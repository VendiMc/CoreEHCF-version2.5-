<?php

namespace VitalHCF\Task\event;

use VitalHCF\{Loader, Factions};
use VitalHCF\player\Player;

use pocketmine\scheduler\Task;
use pocketmine\utils\{Config, TexFormat as TE};

class FactionTask extends Task {

    /**
     * FactionTask Constructor.
     */
    public function __construct(){
        
    }

    /**
     * @param Int $currentTick
     * @return void
     */
    public function onRun(Int $currentTick) : void {
        $this->verificationFactions();
    }

    /**
	 * @return void
	 */
	protected function verificationFactions(){
		$factions = [];
		foreach(Loader::getInstance()->getServer()->getOnlinePlayers() as $player){
			if($player instanceof Player && Factions::inFaction($player->getName())){
				$factions[] = Factions::getFaction($player->getName());
			}
		}
		if(count($factions) > 0){
			foreach($factions as $faction){
				if(!Factions::isFreezeTime($faction)){
					Factions::setStrength($faction, Factions::getMaxStrength($faction));
				}
			}
		}
	}
}

?>