<?php

namespace VitalHCF\commands;

use VitalHCF\Loader;
use VitalHCF\player\Player;

use pocketmine\item\Tool;
use pocketmine\utils\TextFormat as TE;
use pocketmine\command\{CommandSender, PluginCommand};

class RenameCommand extends PluginCommand {

    /**
     * RenameCommand Constructor.
     */
    public function __construct(){
        parent::__construct("rename", Loader::getInstance());
        $this->setPermission("rename.command.use");
    }

    /**
	 * @param CommandSender $sender
	 * @param String $label
	 * @param Array $args
	 * @return void
	 */
	public function execute(CommandSender $sender, String $label, Array $args) : void {
		if(!$sender->hasPermission("rename.command.use")){
			$sender->sendMessage(TE::RED."You have not permissions to use this command");
			return;
		}
		if(count($args) === 0){
			$sender->sendMessage(TE::RED."Use: /{$label} <itemName> (You can use '&' to put colors)");
			return;
		}
		$item = $sender->getInventory()->getItemInHand();
		if($item === null){
			return;
		}
		if(!$item instanceof Tool && !$sender->isOp()){
			$sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_not_rename_other_item")));
			return;
		}
		$item->clearCustomName();
		$item->setCustomName(str_replace("&", "§", implode(" ", $args)));
		$sender->getInventory()->setItemInHand($item);
		$sender->sendMessage(str_replace(["&", "{itemName}"], ["§", implode(" ", $args)], Loader::getConfiguration("messages")->get("player_rename_correctly")));
	}
}

?>