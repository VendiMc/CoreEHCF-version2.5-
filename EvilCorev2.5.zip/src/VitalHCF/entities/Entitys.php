<?php

namespace VitalHCF\entities;

use VitalHCF\Loader;

use pocketmine\tile\Tile;

use VitalHCF\entities\tiles\{
	MonsterTileSpawner,
};
use VitalHCF\entities\spawnable\{
	Cow, Enderman, Villager, Pig, Creeper,
};
use pocketmine\entity\Entity;

class Entitys {
	
	/**
	 * @return void
	 */
	public static function init() : void {
		//ENTITYS
		Entity::registerEntity(Cow::class, true, ["Cow"]);
		Entity::registerEntity(Enderman::class, true, ["Enderman"]);
		Entity::registerEntity(Villager::class, true, ["Villager"]);
		Entity::registerEntity(Pig::class, true, ["Pig"]);
		Entity::registerEntity(Creeper::class, true, ["Creeper"]);
			
		Entity::registerEntity(ThrownEnderPearl::class, true, ["ThrownEnderpearl"]);
		Entity::registerEntity(ThrownSplashPotion::class, true, ["ThrownSplashpotion"]);
		
		//TILES
		Tile::registerTile(MonsterTileSpawner::class);
	}
	
	/**
	 * @return Array
	 */
	public static function getEntitysType() : Array {
		return Loader::getDefaultConfig("Entitys");
	}
}

?>