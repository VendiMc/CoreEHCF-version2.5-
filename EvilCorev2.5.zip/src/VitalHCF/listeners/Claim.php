<?php

namespace VitalHCF\listeners;

use VitalHCF\{Loader, Factions};
use VitalHCF\player\Player;

use VitalHCF\API\System;

use pocketmine\event\Listener;
use pocketmine\utils\TextFormat as TE;
use pocketmine\math\Vector3;
use pocketmine\block\Block;

use pocketmine\event\player\{PlayerChatEvent, PlayerInteractEvent};
use pocketmine\event\block\BlockBreakEvent;

class Claim implements Listener {

    /** @var Loader */
    protected $plugin;

    /**
     * Claim Constructor.
     * @param Loader $plugin
     */
    public function __construct(Loader $plugin){
        $this->plugin = $plugin;
    }

    /**
     * @param PlayerInteractEvent $event
     * @return void
     */
    public function onPlayerInteractEvent(PlayerInteractEvent $event) : void {
        $player = $event->getPlayer();
        $block = $event->getBlock();
        $spawn = new Vector3(0, 0, 0);
        if($player->isInteract()){
			if($player->getInventory()->getItemInHand()->getCustomName() === TE::DARK_PURPLE."Claim Tool" && $event->getAction() === PlayerInteractEvent::RIGHT_CLICK_BLOCK){
				$event->setCancelled(true);
         	   if((int)$spawn->distance($block) < 400 && !$player->isGodMode()){
           	     $player->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_distance_zone_spawn")));
	                $event->setCancelled(true);
	            }else{
	            	if(!System::isPosition($player, 1)){
						$player->sendMessage(str_replace(["&", "{positionX}", "{positionZ}"], ["§", $block->x, $block->z], Loader::getConfiguration("messages")->get("player_location_zone_first")));
	            		System::deleteTower($player, 1);
	                	System::createTower($player, $block, Block::get(Block::GLASS));
	             	   System::setPosition($player, $block, 1);
	            	    $event->setCancelled(true);
	            	}elseif(!System::isPosition($player, 2)){
						$player->sendMessage(str_replace(["&", "{positionX}", "{positionZ}"], ["§", $block->x, $block->z], Loader::getConfiguration("messages")->get("player_location_zone_second")));
	            		System::deleteTower($player, 2);
	                	System::createTower($player, $block, Block::get(Block::GLASS));
	                	System::setPosition($player, $block, 2);
	                	System::checkClaim($player, System::getPosition($player, 1), System::getPosition($player, 2));
	                	$event->setCancelled(true);
	                }
	            }
	        }
	    }
	}

    /**
     * @param PlayerChatEvent $event
     * @return void
     */
    public function onPlayerChatEvent(PlayerChatEvent $event) : void {
        $player = $event->getPlayer();
        $args = $event->getMessage();
        if($player->isInteract() && $args === "accept"){
            if(!System::isPosition($player, 1) and !System::isPosition($player, 2)){
                $player->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_not_zone_location")));
                $event->setCancelled(true);
                return;
            }
            if(Factions::getBalance(Factions::getFaction($player->getName())) < $player->getClaimCost()){
                $player->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_not_have_money_for_claim_zone")));
                $event->setCancelled(true);
                return;
            }
            Factions::claimRegion(Factions::getFaction($player->getName()), $player->getLevel()->getName(), System::getPosition($player, 1), System::getPosition($player, 2), Factions::FACTION);
            Factions::reduceBalance(Factions::getFaction($player->getName()), $player->getClaimCost());
            System::deleteTower($player, 1);
            System::deleteTower($player, 2);
            System::deletePosition($player);
            $player->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_zone_accept")));
            $event->setCancelled(true);
        }
        if($player->isInteract() && $args === "cancel"){
            if(!System::isPosition($player, 1) and !System::isPosition($player, 2)){
                $player->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_not_zone_location")));
                $event->setCancelled(true);
                return;
            }
            System::deleteTower($player, 1);
            System::deleteTower($player, 2);
            System::deletePosition($player);
            $player->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_zone_cancel")));
            $event->setCancelled(true);
        }
    }
}

?>