<?php

namespace VitalHCF\provider;

use VitalHCF\Loader;
use SQLite3;

use pocketmine\utils\Config;
use pocketmine\Server;
use pocketmine\utils\TextFormat as TE;

class SQLite3Provider {
	
	/** @var SQLite3 */
	protected static $database = null;
	
	/**
	 * @return void
	 */
	public static function init() : void {
		$database = new SQLite3(Loader::getInstance()->getDataFolder()."DataBase.db");
		$database->exec("CREATE TABLE IF NOT EXISTS zoneclaims(factionName TEXT PRIMARY KEY, protection TEXT, x1 INT, y1 INT, z1 INT, x2 INT, y2 INT, z2 INT, level TEXT);");
		$database->exec("CREATE TABLE IF NOT EXISTS homes(factionName TEXT PRIMARY KEY, x INT, y INT, z INT, level TEXT);");
		$database->exec("CREATE TABLE IF NOT EXISTS player_data(playerName TEXT PRIMARY KEY, factionRank TEXT, factionName TEXT);");
		$database->exec("CREATE TABLE IF NOT EXISTS balance(factionName TEXT PRIMARY KEY, money INT);");
		$database->exec("CREATE TABLE IF NOT EXISTS strength(factionName TEXT PRIMARY KEY, dtr INT);");
		self::$database = $database;
		Loader::getInstance()->getLogger()->info(TE::GREEN."SQLite3Provider » was loaded successfully!");
	}
	
	/**
	 * @return SQLite3
	 */
	public function getDataBase() : SQLite3 {
		return self::$database;
	}
	
	/**
	 * @return void
	 */
	public static function disconnect() : void {
		$connection = self::$database;
		$connection->close();
		unset($connection);
	}
}

?>