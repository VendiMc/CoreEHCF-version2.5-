<?php

namespace VitalHCF\item\specials;

use pocketmine\item\Item;

class Custom extends Item {
	
	/**
	 * Custom Constructor.
	 * @param Int $id
	 * @param String $customName
	 * @param Array $customLore
	 * @param Array $customEnchants
	 * @param Int $meta
	 */
	public function __construct(?Int $id, ?String $customName, ?Array $customLore = [], ?Array $customEnchants = [], Int $meta = 0){
		$this->setCustomName($customName);
		$this->setLore($customLore);
		if(!empty($customEnchants)){
			foreach($customEnchants as $enchant){
				$this->addEnchantment($enchant);
			}
		}
		parent::__construct($id, $meta);
	}
}

?>