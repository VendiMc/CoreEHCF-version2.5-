<?php

namespace VitalHCF\listeners;

use VitalHCF\{Loader, Factions};
use VitalHCF\player\Player;

use VitalHCF\entities\spawnable\Villager;

use pocketmine\entity\Entity;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerQuitEvent;

class Logout implements Listener {
	
	/** @var Loader */
	protected $plugin;
	
	/**
	 * Logout Constructor.
	 *@param Loader $plugin
	 */
	public function __construct(Loader $plugin){
		$this->plugin = $plugin;
	}
	
	/**
	 * @param PlayerQuitEvent $event
	 * @return void
	 */
	public function onPlayerQuitEvent(PlayerQuitEvent $event) : void {
		$player = $event->getPlayer();
		if($player->isCombatTag()||!$player->isLogout()){
			if(Factions::isSpawnRegion($player)) return;
			
			$nbt = Entity::createBaseNBT($player, null, $player->yaw, $player->pitch);
			$villager = new Villager($player->getLevel(), $nbt, $player);
			$villager->handleData($player);
			$player->getLevel()->addEntity($villager);
			$villager->spawnToAll();
		}
	}
}

?>