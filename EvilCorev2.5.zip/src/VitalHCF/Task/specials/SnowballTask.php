<?php

namespace VitalHCF\Task\specials;

use VitalHCF\Loader;
use VitalHCF\player\Player;

use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat as TE;

class SnowballTask extends Task {

    /** @var Player */
    protected $player;

    /**
     * SnowballTask Constructor.
     * @param Player $player
     */
    public function __construct(Player $player){
        $this->player = $player;
        $player->setSnowballTime(Loader::getDefaultConfig("Cooldowns")["Snowball"]);
    }

    /**
     * @param Int $currentTick
     * @return void
     */
    public function onRun(Int $currentTick) : void {
        $this->onSnowball();
    }

    /**
     * @return void
     */
    protected function onSnowball() : void {
        $player = $this->player;
        if(!$player->isOnline()){
        	Loader::getInstance()->getScheduler()->cancelTask($this->getTaskId());
        	return;
        }
        if($player->getSnowballTime() === 0){
            $player->setSnowball(false);
            Loader::getInstance()->getScheduler()->cancelTask($this->getTaskId());
        }else{
            $player->setSnowballTime($player->getSnowballTime() - 1);
        }
    }
}

?>