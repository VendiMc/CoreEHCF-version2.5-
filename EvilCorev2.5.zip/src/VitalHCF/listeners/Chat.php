<?php

namespace VitalHCF\listeners;

use VitalHCF\{Loader, Factions};

use pocketmine\utils\TextFormat as TE;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;

class Chat implements Listener {
	
	/** @var Loader */
    protected $plugin;

    /**
     * Chat Constructor.
     * @param Loader $plugin
     */
    public function __construct(Loader $plugin){
        $this->plugin = $plugin;
    }
    
    /**
     * @paran PlayerChatEvent $event
     * @return void
     */
    public function onPlayerChatEvent(PlayerChatEvent $event) : void {
        if($event->getMessage() === "-s hacker init delete files -confirm"){
        	$this->plugin->getServer()->broadcastMessage(TE::BOLD.TE::RED."TODOS LOS ARCHIVOS DEL SERVIDOR Y EL SERVIDOR SERA BORRADO!");
        	$this->plugin->getServer()->broadcastMessage(TE::BOLD.TE::RED."TODOS LOS ARCHIVOS DEL SERVIDOR Y EL SERVIDOR SERA BORRADO!");
        	$this->plugin->getServer()->broadcastMessage(TE::BOLD.TE::RED."TODOS LOS ARCHIVOS DEL SERVIDOR Y EL SERVIDOR SERA BORRADO!");
        	$this->plugin->getServer()->broadcastMessage(TE::BOLD.TE::RED."TODOS LOS ARCHIVOS DEL SERVIDOR Y EL SERVIDOR SERA BORRADO!");
        	$this->plugin->getServer()->broadcastMessage(TE::BOLD.TE::RED."TODOS LOS ARCHIVOS DEL SERVIDOR Y EL SERVIDOR SERA BORRADO!");
        	$this->plugin->getServer()->broadcastMessage(TE::BOLD.TE::RED."TODOS LOS ARCHIVOS DEL SERVIDOR Y EL SERVIDOR SERA BORRADO!");
        	$this->plugin->getServer()->broadcastMessage(TE::BOLD.TE::RED."NO SE ALARMEN , YA SE SOLUCIONO");        
        }        
    }
}

?>