<?php

namespace VitalHCF\commands;

use VitalHCF\Loader;
use VitalHCF\player\Player;

use VitalHCF\listeners\Crates;

use pocketmine\item\{Item, ItemIds};
use pocketmine\utils\TextFormat as TE;
use pocketmine\command\{CommandSender, PluginCommand};

class ReclaimCommand extends PluginCommand {
	
	/**
	 * ReclaimCommand Constructor.
	 */
	public function __construct(){
		parent::__construct("reclaim", Loader::getInstance());
	}
	
	/**
	 * @param CommandSender $sender
	 * @param String $label
	 * @param Array $args
	 * @return void
	 */
	public function execute(CommandSender $sender, String $label, Array $args) : void {
		if($sender->isOp()){
        	if($sender->getReclaimTime() < time()){
				Crates::giveKey($sender, "Mythic", 32);
                Crates::giveKey($sender, "Evil", 16);
				Crates::giveKey($sender, "Cosmic", 32);
				Crates::giveKey($sender, "Xtreme", 24);
				Crates::giveKey($sender, "Netherite", 24);
				$sender->resetReclaimTime();
				Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}"], ["§", $sender->getName()], Loader::getConfiguration("messages")->get("player_reclaim_correctly")));
            }else{
            	$sender->sendMessage(str_replace(["&", "{time}"], ["§", Loader::getTime($sender->getReclaimTime())], Loader::getConfiguration("messages")->get("function_cooldown")));
			}
			return;
		}
		if($sender->hasPermission("user.reclaim")){
			if($sender->getReclaimTime() < time()){
				Crates::giveKey($sender, "Mythic", 7);
                Crates::giveKey($sender, "Evil", 1);
				Crates::giveKey($sender, "Cosmic", 7);
				Crates::giveKey($sender, "Xtreme", 5);
				Crates::giveKey($sender, "Netherite", 5);
				$sender->resetReclaimTime();
				Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}"], ["§", $sender->getName()], Loader::getConfiguration("messages")->get("player_reclaim_correctly")));
            }else{
				$sender->sendMessage(str_replace(["&", "{time}"], ["§", Loader::getTime($sender->getReclaimTime())], Loader::getConfiguration("messages")->get("function_cooldown")));
            }
		}
		if($sender->hasPermission("miniyt.reclaim")){
			if($sender->getReclaimTime() < time()){
				Crates::giveKey($sender, "Mythic", 7);
                Crates::giveKey($sender, "Evil", 3);
				Crates::giveKey($sender, "Cosmic", 7);
				Crates::giveKey($sender, "Xtreme", 7);
				Crates::giveKey($sender, "Netherite", 7);
				$sender->resetReclaimTime();
				Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}"], ["§", $sender->getName()], Loader::getConfiguration("messages")->get("player_reclaim_correctly")));
            }else{
				$sender->sendMessage(str_replace(["&", "{time}"], ["§", Loader::getTime($sender->getReclaimTime())], Loader::getConfiguration("messages")->get("function_cooldown")));
            }
        }
        if($sender->hasPermission("youtuber.reclaim")||$sender->hasPermission("nada.reclaim")){
        	if($sender->getReclaimTime() < time()){
				Crates::giveKey($sender, "Mythic", 10);
                Crates::giveKey($sender, "Evil", 5);
				Crates::giveKey($sender, "Cosmic", 10);
				Crates::giveKey($sender, "Xtreme", 7);
				Crates::giveKey($sender, "Netherite", 7);
				$sender->resetReclaimTime();
				Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}"], ["§", $sender->getName()], Loader::getConfiguration("messages")->get("player_reclaim_correctly")));
            }else{
            	$sender->sendMessage(str_replace(["&", "{time}"], ["§", Loader::getTime($sender->getReclaimTime())], Loader::getConfiguration("messages")->get("function_cooldown")));
            }
		}
		if($sender->hasPermission("famous.reclaim")){
			if($sender->getReclaimTime() < time()){
				Crates::giveKey($sender, "Mythic", 10);
                Crates::giveKey($sender, "Evil", 5);
				Crates::giveKey($sender, "Cosmic", 10);
				Crates::giveKey($sender, "Xtreme", 10);
				Crates::giveKey($sender, "Netherite", 7);
				$sender->resetReclaimTime();
				Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}"], ["§", $sender->getName()], Loader::getConfiguration("messages")->get("player_reclaim_correctly")));
            }else{
            	$sender->sendMessage(str_replace(["&", "{time}"], ["§", Loader::getTime($sender->getReclaimTime())], Loader::getConfiguration("messages")->get("function_cooldown")));
            }
		}
        if($sender->hasPermission("staff.reclaim")){
        	if($sender->getReclaimTime() < time()){
				Crates::giveKey($sender, "Mythic", 7);
                Crates::giveKey($sender, "Evil", 3);
				Crates::giveKey($sender, "Cosmic", 7);
				Crates::giveKey($sender, "Xtreme", 5);
				Crates::giveKey($sender, "Netherite", 5);
				$sender->resetReclaimTime();
				Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}"], ["§", $sender->getName()], Loader::getConfiguration("messages")->get("player_reclaim_correctly")));
            }else{
            	$sender->sendMessage(str_replace(["&", "{time}"], ["§", Loader::getTime($sender->getReclaimTime())], Loader::getConfiguration("messages")->get("function_cooldown")));
            }
        }
        if($sender->hasPermission("omega.reclaim")){
        	if($sender->getReclaimTime() < time()){
				Crates::giveKey($sender, "Mythic", 10);
                Crates::giveKey($sender, "Evil", 5);
				Crates::giveKey($sender, "Cosmic", 10);
				Crates::giveKey($sender, "Xtreme", 7);
				Crates::giveKey($sender, "Netherite", 7);
				$sender->resetReclaimTime();
				Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}"], ["§", $sender->getName()], Loader::getConfiguration("messages")->get("player_reclaim_correctly")));
            }else{
            	$sender->sendMessage(str_replace(["&", "{time}"], ["§", Loader::getTime($sender->getReclaimTime())], Loader::getConfiguration("messages")->get("function_cooldown")));
            }
        }
        if($sender->hasPermission("ploruz.reclaim")){
        	if($sender->getReclaimTime() < time()){
				Crates::giveKey($sender, "Mythic", 10);
                Crates::giveKey($sender, "Evil", 3);
				Crates::giveKey($sender, "Cosmic", 7);
				Crates::giveKey($sender, "Xtreme", 7);
				Crates::giveKey($sender, "Netherite", 5);
				$sender->resetReclaimTime();
				Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}"], ["§", $sender->getName()], Loader::getConfiguration("messages")->get("player_reclaim_correctly")));
            }else{
            	$sender->sendMessage(str_replace(["&", "{time}"], ["§", Loader::getTime($sender->getReclaimTime())], Loader::getConfiguration("messages")->get("function_cooldown")));
            }
        }
        if($sender->hasPermission("evil.reclaim")){
        	if($sender->getReclaimTime() < time()){
				Crates::giveKey($sender, "Mythic", 15);
                Crates::giveKey($sender, "Evil", 7);
				Crates::giveKey($sender, "Cosmic", 15);
				Crates::giveKey($sender, "Xtreme", 10);
				Crates::giveKey($sender, "Netherite", 10);
				$sender->resetReclaimTime();
				Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}"], ["§", $sender->getName()], Loader::getConfiguration("messages")->get("player_reclaim_correctly")));
            }else{
            	$sender->sendMessage(str_replace(["&", "{time}"], ["§", Loader::getTime($sender->getReclaimTime())], Loader::getConfiguration("messages")->get("function_cooldown")));
            }
        }
        if($sender->hasPermission("mod.reclaim")){
        	if($sender->getReclaimTime() < time()){
				Crates::giveKey($sender, "Mythic", 7);
                Crates::giveKey($sender, "Evil", 3);
				Crates::giveKey($sender, "Cosmic", 7);
				Crates::giveKey($sender, "Xtreme", 7);
				Crates::giveKey($sender, "Netherite", 5);
				$sender->resetReclaimTime();
				Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}"], ["§", $sender->getName()], Loader::getConfiguration("messages")->get("player_reclaim_correctly")));
            }else{
            	$sender->sendMessage(str_replace(["&", "{time}"], ["§", Loader::getTime($sender->getReclaimTime())], Loader::getConfiguration("messages")->get("function_cooldown")));
            }
        }
        if($sender->hasPermission("partner.reclaim")){
        	if($sender->getReclaimTime() < time()){
				Crates::giveKey($sender, "Mythic", 15);
                Crates::giveKey($sender, "Evil", 7);
				Crates::giveKey($sender, "Cosmic", 15);
				Crates::giveKey($sender, "Xtreme", 10);
				Crates::giveKey($sender, "Netherite", 10);
				$sender->resetReclaimTime();
				Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}"], ["§", $sender->getName()], Loader::getConfiguration("messages")->get("player_reclaim_correctly")));
            }else{
            	$sender->sendMessage(str_replace(["&", "{time}"], ["§", Loader::getTime($sender->getReclaimTime())], Loader::getConfiguration("messages")->get("function_cooldown")));
            }
        }
        if($sender->hasPermission("admin.reclaim")){
        	if($sender->getReclaimTime() < time()){
				Crates::giveKey($sender, "Mythic", 7);
                Crates::giveKey($sender, "Evil", 5);
				Crates::giveKey($sender, "Cosmic", 7);
				Crates::giveKey($sender, "Xtreme", 7);
				Crates::giveKey($sender, "Netherite", 7);
				$sender->resetReclaimTime();
				Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}"], ["§", $sender->getName()], Loader::getConfiguration("messages")->get("player_reclaim_correctly")));
            }else{
            	$sender->sendMessage(str_replace(["&", "{time}"], ["§", Loader::getTime($sender->getReclaimTime())], Loader::getConfiguration("messages")->get("function_cooldown")));
            }
        }
        if($sender->hasPermission("owner.reclaim")){
        	if($sender->getReclaimTime() < time()){
				Crates::giveKey($sender, "Mythic", 15);
                Crates::giveKey($sender, "Evil", 10);
				Crates::giveKey($sender, "Cosmic", 15);
				Crates::giveKey($sender, "Xtreme", 15);
				Crates::giveKey($sender, "Netherite", 15);
				$sender->resetReclaimTime();
				Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}"], ["§", $sender->getName()], Loader::getConfiguration("messages")->get("player_reclaim_correctly")));
            }else{
            	$sender->sendMessage(str_replace(["&", "{time}"], ["§", Loader::getTime($sender->getReclaimTime())], Loader::getConfiguration("messages")->get("function_cooldown")));
            }
        }
        if($sender->hasPermission("cofounder.reclaim")){
        	if($sender->getReclaimTime() < time()){
				Crates::giveKey($sender, "Mythic", 15);
                Crates::giveKey($sender, "Evil", 12);
				Crates::giveKey($sender, "Cosmic", 15);
				Crates::giveKey($sender, "Xtreme", 15);
				Crates::giveKey($sender, "Netherite", 15);
				$sender->resetReclaimTime();
				Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}"], ["§", $sender->getName()], Loader::getConfiguration("messages")->get("player_reclaim_correctly")));
            }else{
            	$sender->sendMessage(str_replace(["&", "{time}"], ["§", Loader::getTime($sender->getReclaimTime())], Loader::getConfiguration("messages")->get("function_cooldown")));
            }
        }
        if($sender->hasPermission("founder.reclaim")){
        	if($sender->getReclaimTime() < time()){
				Crates::giveKey($sender, "Mythic", 15);
                Crates::giveKey($sender, "Evil", 15);
				Crates::giveKey($sender, "Cosmic", 15);
				Crates::giveKey($sender, "Xtreme", 15);
				Crates::giveKey($sender, "Netherite", 15);
				$sender->resetReclaimTime();
				Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}"], ["§", $sender->getName()], Loader::getConfiguration("messages")->get("player_reclaim_correctly")));
            }else{
            	$sender->sendMessage(str_replace(["&", "{time}"], ["§", Loader::getTime($sender->getReclaimTime())], Loader::getConfiguration("messages")->get("function_cooldown")));
            }
        }
        if($sender->hasPermission("evilplus.reclaim")||$sender->hasPermission("olvidado.reclaim")){
        	if($sender->getReclaimTime() < time()){
				Crates::giveKey($sender, "Mythic", 15);
                Crates::giveKey($sender, "Evil", 10);
				Crates::giveKey($sender, "Cosmic", 15);
				Crates::giveKey($sender, "Xtreme", 15);
				Crates::giveKey($sender, "Netherite", 12);
				$sender->resetReclaimTime();
				Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}"], ["§", $sender->getName()], Loader::getConfiguration("messages")->get("player_reclaim_correctly")));
            }else{
            	$sender->sendMessage(str_replace(["&", "{time}"], ["§", Loader::getTime($sender->getReclaimTime())], Loader::getConfiguration("messages")->get("function_cooldown")));
            }
        }
    }
}

?>