<?php

namespace VitalHCF\listeners;

use VitalHCF\{Loader, Factions};
use VitalHCF\player\Player;
use VitalHCF\Task\FreezeTimeTask;

use pocketmine\event\Listener;
use pocketmine\utils\TextFormat as TE;
use pocketmine\math\Vector3;
use pocketmine\item\{ItemIds, BlockIds};

use pocketmine\block\{ItemFrame, Door, Fence, FenceGate, Trapdoor, Chest, TrappedChest};
use pocketmine\item\{Bucket, Hoe, Shovel};

use pocketmine\event\entity\{EntityDamageEvent, EntityDamageByEntityEvent};
use pocketmine\event\block\{BlockBreakEvent, BlockPlaceEvent, BlockSpreadEvent, SignChangeEvent};
use pocketmine\event\player\{PlayerMoveEvent, PlayerInteractEvent, PlayerJoinEvent, PlayerQuitEvent, PlayerDeathEvent, PlayerChatEvent};

use pocketmine\tile\Sign;
use pocketmine\block\SignPost;

class Faction implements Listener {
	
	const ELEVATOR_UP = "up", ELEVATOR_DOWN = "down";

    /** @var Loader */
    protected $plugin;

    /**
     * Faction Constructor.
     * @param Loader $plugin
     */
    public function __construct(Loader $plugin){
        $this->plugin = $plugin;
	}

	/**
	 * @param PlayerJoinEvent $event
	 * @return void
	 */
	public function onPlayerJoinEvent(PlayerJoinEvent $event) : void {
		$player = $event->getPlayer();
		if(Factions::inFaction($player->getName())){
			foreach(Factions::getPlayers(Factions::getFaction($player->getName())) as $value){
				$online = $this->plugin->getServer()->getPlayer($value);
				if($online instanceof Player){
					$online->sendMessage(str_replace(["&", "{playerName}"], ["§", $player->getName()], Loader::getConfiguration("messages")->get("faction_player_connect")));
				}
			}
		}
	}

	/**
	 * @param PlayerQuitEvent $event
	 * @return void
	 */
	public function onPlayerQuitEvent(PlayerQuitEvent $event) : void {
		$player = $event->getPlayer();
		if(Factions::inFaction($player->getName())){
			foreach(Factions::getPlayers(Factions::getFaction($player->getName())) as $value){
				$online = $this->plugin->getServer()->getPlayer($value);
				if($online instanceof Player){
					$online->sendMessage(str_replace(["&", "{playerName}"], ["§", $player->getName()], Loader::getConfiguration("messages")->get("faction_player_desconnect")));
				}
			}
		}
	}

	/**
	 * @param PlayerDeathEvent $event
	 * @return void
	 */
	public function onPlayerDeathEvent(PlayerDeathEvent $event) : void {
		$player = $event->getPlayer();
		if(Factions::inFaction($player->getName())){
			Factions::reduceStrength(Factions::getFaction($player->getName()));
			foreach(Factions::getPlayers(Factions::getFaction($player->getName())) as $value){
				$online = $this->plugin->getServer()->getPlayer($value);
				if($online instanceof Player){
					$online->sendMessage(str_replace(["&", "{playerName}", "{currentDtr}", "%n%"], ["§", $player->getName(), Factions::getStrength(Factions::getFaction($player->getName())), "\n"], Loader::getConfiguration("messages")->get("faction_player_death")));
				}
				//TODO:
			}
			//TODO:
			if(!Factions::isFreezeTime(Factions::getFaction($player->getName()))){
				Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new FreezeTimeTask(Factions::getFaction($player->getName())), 20);
			}
		}
	}

	/**
	 * @param PlayerChatEvent $event
	 * @return void
	 */
	public function onPlayerChatEvent(PlayerChatEvent $event) : void {
		$player = $event->getPlayer();
		if(Factions::inFaction($player->getName()) && $player->getChat() === Player::FACTION_CHAT){
			$event->setCancelled(true);
			foreach(Factions::getPlayers(Factions::getFaction($player->getName())) as $value){
				$online = $this->plugin->getServer()->getPlayer($value);
				if($online instanceof Player){
					$online->sendMessage(str_replace(["&", "{playerName}", "{message}"], ["§", $player->getName(), $event->getMessage()], Loader::getConfiguration("messages")->get("faction_player_chat")));
				}
			}
		}
	}

	/**
	 * @param EntityDamageEvent $event
	 * @return void
	 */
	public function onEntityDamageEvent(EntityDamageEvent $event) : void {
		$player = $event->getEntity();
		if($event instanceof EntityDamageByEntityEvent){
			$damager = $event->getDamager();
            if($player instanceof Player && $damager instanceof Player){
				if(Factions::inFaction($player->getName()) && Factions::inFaction($damager->getName())){
					if(Factions::getFaction($player->getName()) === Factions::getFaction($damager->getName())){
						if($player->isTeleportingStuck()||$player->isTeleportingHome()){
							$event->setCancelled(true);
						}else{
							$damager->sendMessage(str_replace(["&", "{playerName}"], ["§", $player->getName()], Loader::getConfiguration("messages")->get("faction_not_damage_member")));
							$event->setCancelled(true);
						}
					}else{
						if($player->isTeleportingHome()){
							$player->setTeleportingHome(false);
							$player->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_move_in_teleport_time")));
						}
						if($player->isTeleportingStuck()){
							$player->setTeleportingStuck(false);
							$player->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_move_in_teleport_time")));
						}
					}
				}else{
					if($player->isTeleportingHome()){
						$player->setTeleportingHome(false);
						$player->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_move_in_teleport_time")));
					}
					if($player->isTeleportingStuck()){
						$player->setTeleportingStuck(false);
						$player->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_move_in_teleport_time")));
					}
				}
			}
		}else{
			if($player instanceof Player){
				if(!Factions::isSpawnRegion($player)){
					if($player->isTeleportingHome()){
						$player->setTeleportingHome(false);
						$player->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_move_in_teleport_time")));
					}
					if($player->isTeleportingStuck()){
						$player->setTeleportingStuck(false);
						$player->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_move_in_teleport_time")));
					}
				}
			}
		}
	}
	
	/**
	 * @param PlayerInteractEvent $event
	 * @return void
	 */
	public function onPlayerInteractEvent(PlayerInteractEvent $event) : void {
		$player = $event->getPlayer();
		$block = $event->getBlock();
		$item = $event->getItem();
		if($player->isGodMode()) return;
		if($block instanceof Fence||$block instanceof FenceGate||$block instanceof Door||$block instanceof Trapdoor){
			if($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_BLOCK){
				if(Factions::isFactionRegion($block)){
					if(!Factions::inFaction($player->getName())){
						$player->setMovementTime(time() + 0.1);
						$player->sendMessage(str_replace(["&", "{claimName}"], ["§", Factions::getRegionName($block)], Loader::getConfiguration("messages")->get("faction_cannot_interact")));
						$event->setCancelled(true);
					}else{
						if(Factions::getRegionName($block) !== Factions::getFaction($player->getName())){
							$player->setMovementTime(time() + 0.1);
							$player->sendMessage(str_replace(["&", "{claimName}"], ["§", Factions::getRegionName($block)], Loader::getConfiguration("messages")->get("faction_cannot_interact")));
							$event->setCancelled(true);
						}
					}
				}
			}
		}
		if($block instanceof Chest){
			if($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_BLOCK){
				if(Factions::isFactionRegion($block)){
					if(!Factions::inFaction($player->getName())){
						$player->sendMessage(str_replace(["&", "{claimName}"], ["§", Factions::getRegionName($block)], Loader::getConfiguration("messages")->get("faction_cannot_interact")));
						$event->setCancelled(true);
					}else{
						if(Factions::getRegionName($block) !== Factions::getFaction($player->getName())){
							$player->sendMessage(str_replace(["&", "{claimName}"], ["§", Factions::getRegionName($block)], Loader::getConfiguration("messages")->get("faction_cannot_interact")));
							$event->setCancelled(true);
						}
					}
				}
			}
		}
		if($item instanceof Bucket||$item instanceof Hoe||$item instanceof Shovel){
			if($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_BLOCK){
				if(Factions::isFactionRegion($block)){
					if(!Factions::inFaction($player->getName())){
						$player->sendMessage(str_replace(["&", "{claimName}"], ["§", Factions::getRegionName($block)], Loader::getConfiguration("messages")->get("faction_cannot_interact")));
						$event->setCancelled(true);
					}else{
						if(Factions::getRegionName($block) !== Factions::getFaction($player->getName())){
							$player->sendMessage(str_replace(["&", "{claimName}"], ["§", Factions::getRegionName($block)], Loader::getConfiguration("messages")->get("faction_cannot_interact")));
							$event->setCancelled(true);
						}
					}
				}
			}
		}
	}
	
	/**
	 * @param BlockBreakEvent $event
	 * @return void
	 */
	public function onBlockBreak(BlockBreakEvent $event) : void {
		$player = $event->getPlayer();
		$block = $event->getBlock();
		if($player->isGodMode()) return;
		if(Factions::isFactionRegion($block)){
			if($block->isSolid()){
				if(!Factions::inFaction($player->getName())){
					$player->setMovementTime(time() + 0.1);
					$player->sendMessage(str_replace(["&", "{claimName}"], ["§", Factions::getRegionName($block)], Loader::getConfiguration("messages")->get("faction_cannot_interact")));
					$event->setCancelled(true);
				}else{
					if(Factions::getRegionName($block) !== Factions::getFaction($player->getName())){
						$player->setMovementTime(time() + 0.1);
						$player->sendMessage(str_replace(["&", "{claimName}"], ["§", Factions::getRegionName($block)], Loader::getConfiguration("messages")->get("faction_cannot_interact")));
						$event->setCancelled(true);
					}
				}
			}else{
				if(!Factions::inFaction($player->getName())){
					$player->sendMessage(str_replace(["&", "{claimName}"], ["§", Factions::getRegionName($block)], Loader::getConfiguration("messages")->get("faction_cannot_interact")));
					$event->setCancelled(true);
				}else{
					if(Factions::getRegionName($block) !== Factions::getFaction($player->getName())){
						$player->sendMessage(str_replace(["&", "{claimName}"], ["§", Factions::getRegionName($block)], Loader::getConfiguration("messages")->get("faction_cannot_interact")));
						$event->setCancelled(true);
					}
				}
			}
		}
	}

	/**
	 * @param BlockPlaceEvent $event
	 * @return void
	 */
	public function onBlockPlace(BlockPlaceEvent $event) : void {
		$player = $event->getPlayer();
		$block = $event->getBlock();
		if($player->isGodMode()) return;
		if(Factions::isFactionRegion($block)){
			if(!Factions::inFaction($player->getName())){
				$player->setMovementTime(time() + 0.1);
				$player->sendMessage(str_replace(["&", "{claimName}"], ["§", Factions::getRegionName($block)], Loader::getConfiguration("messages")->get("faction_cannot_interact")));
				$event->setCancelled(true);
			}else{
				if(Factions::getRegionName($block) !== Factions::getFaction($player->getName())){
					$player->setMovementTime(time() + 0.1);
					$player->sendMessage(str_replace(["&", "{claimName}"], ["§", Factions::getRegionName($block)], Loader::getConfiguration("messages")->get("faction_cannot_interact")));
					$event->setCancelled(true);
				}
			}
		}
	}
    
    /**
     * @param PlayerMoveEvent $event
     * @return void
     */
    public function onPlayerMoveEvent(PlayerMoveEvent $event) : void {
		$player = $event->getPlayer();
		if($player->isMovementTime()){
			$event->setCancelled(true);
		}
    	if($player->getRegion() !== $player->getCurrentRegion()){
    		if($player->getCurrentRegion() === "Spawn"){
    			$player->sendMessage(TE::GRAY."Now Leaving: ".TE::RED.$player->getRegion().TE::YELLOW." (".TE::RED."Deathban".TE::YELLOW.")");
				$player->sendMessage(TE::GRAY."Now Entering: ".TE::RED."Spawn".TE::YELLOW." (".TE::GREEN."No-Deathban".TE::YELLOW.")");
			}else{ 
				if($player->getRegion() === "Spawn"){
					$player->sendMessage(TE::GRAY."Now Leaving: ".TE::RED."Spawn".TE::YELLOW." (".TE::GREEN."No-Deathban".TE::YELLOW.")");
					$player->sendMessage(TE::GRAY."Now Entering: ".TE::RED.$player->getCurrentRegion().TE::YELLOW." (".TE::RED."Deathban".TE::YELLOW.")");
				}else{
					$region = $player->getRegion() === Factions::getFaction($player->getName()) ? TE::GREEN.$player->getRegion() : TE::RED.$player->getRegion();
					$currentRegion = $player->getCurrentRegion() === Factions::getFaction($player->getName()) ? TE::GREEN.$player->getCurrentRegion() : TE::RED.$player->getCurrentRegion();
					$player->sendMessage(TE::GRAY."Now Leaving: ".$region.TE::YELLOW." (".TE::RED."Deathban".TE::YELLOW.")");
					$player->sendMessage(TE::GRAY."Now Entering: ".TE::RED.$currentRegion.TE::YELLOW." (".TE::RED."Deathban".TE::YELLOW.")");
				}
			}
			$player->setRegion($player->getCurrentRegion());
		}
		if($event->getTo()->getX() !== $event->getFrom()->getX() and $event->getTo()->getZ() != $event->getFrom()->getZ() && $player->isTeleportingHome()){
			$player->setTeleportingHome(false);
			$player->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_move_in_teleport_time")));
		}
		if($event->getTo()->getX() !== $event->getFrom()->getX() and $event->getTo()->getZ() != $event->getFrom()->getZ() && $player->isTeleportingStuck()){
			$player->setTeleportingStuck(false);
			$player->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_move_in_teleport_time")));
		}
		if($event->getTo()->getX() !== $event->getFrom()->getX() and $event->getTo()->getZ() != $event->getFrom()->getZ() && $player->isLogout()){
			$player->setLogout(false);
			$player->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_is_in_logout_time")));
		}
		$blockIdAt = $player->getLevel()->getBlockIdAt($player->x, $player->y, $player->z);
		if(in_array($blockIdAt, Loader::getDefaultConfig("block_ids"))){
			$player->changeWorld();
		}
    }
    
    /**
     * @param BlockSpreadEvent $event
     * @return void
	 */
	public function onBlockSpreadEvent(BlockSpreadEvent $event){
		$levelName = $event->getBlock()->getLevel()->getFolderName();
		if(!Loader::getDefaultConfig("SpreadWater")){
			$event->setCancelled(true);
		}else{
			$event->setCancelled(false);
		}
	} 
	
	/**
	 * @param SignChangeEvent $event
	 * @return void
	 */
	public function onSignChangeEvent(SignChangeEvent $event) : void {
		if($event->getLine(0) !== "[elevator]"){
			return;
		}
		if($event->getLine(1) === "up"||$event->getLine(1) === "Up"||$event->getLine(1) === "down"||$event->getLine(1) === "Down"){
			$event->setLine(0, TE::RED."[Elevator]");
			$event->setLine(1, $event->getLine(1));
		}
	}
	
	/**
	 * @param PlayerInteractEvent $event
	 * @return void
	 */
	public function onInteractEvent(PlayerInteractEvent $event) : void {
		$player = $event->getPlayer();
		$block = $event->getBlock();
		$level = $this->plugin->getServer()->getDefaultLevel();
		$diff = $level->getTileAt($block->getX(), $block->getY(), $block->getZ());
		if($diff instanceof Sign){
			if($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_BLOCK){
				$line = $diff->getText();
				if($line[0] === TE::RED."[Elevator]"){
					if($line[1] === "up"){
						$this->teleportToSign($player, new Vector3($block->getX(), $block->getY(), $block->getZ()), $this->getSignText($line[1]));
					}elseif($line[1] === "down"){
						$this->teleportToSign($player, new Vector3($block->getX(), $block->getY(), $block->getZ()), $this->getSignText($line[1]));
					}
				}
			}
		}
	}
	
	/**
	 * @param Int $x
	 * @param Int $y
	 * @param Int $z
	 * @return null|Int
	 */
	protected function getTextDown(Int $x, Int $y, Int $z){
		$level = $this->plugin->getServer()->getDefaultLevel();
		for($i = $y - 1; $i >= 0; $i--){
			$diff = $level->getTileAt($x, $i, $z);
			if($diff instanceof Sign){
				$line = $diff->getText();
				if($line[0] === TE::RED."[Elevator]"){
					return $i;
				}
			}
		}
		return $y;
	}
	
	/**
	 * @param Int $x
	 * @param Int $y
	 * @param Int $z
	 * @return null|Int
	 */
	protected function getTextUp(Int $x, Int $y, Int $z){
		$level = $this->plugin->getServer()->getDefaultLevel();
		for($i = $y + 1; $i <= 256; $i++){
			$diff = $level->getTileAt($x, $i, $z);
			if($diff instanceof Sign){
				$line = $diff->getText();
				if($line[0] === TE::RED."[Elevator]"){
					return $i;
				}
			}
		}
		return $y;
	}
	
	/**
	 * @param Int $x
	 * @param Int $y
	 * @param Int $z
	 * @return bool
	 */
	protected function isSign(String $signType, Int $x, Int $y, Int $z) : bool {
		$default = false;
		$level = $this->plugin->getServer()->getDefaultLevel();
		if($signType === self::ELEVATOR_UP){
			for($i = $y + 1; $i <= 256; $i++){
				$diff = $level->getTileAt($x, $i, $z);
				if($diff instanceof Sign){
					$line = $diff->getText();
					if($line[0] === TE::RED."[Elevator]"){
						$default = true;
					}
				}
			}
		}elseif($signType === self::ELEVATOR_DOWN){
			for($i = $y - 1; $i >= 0; $i--){
				$diff = $level->getTileAt($x, $i, $z);
				if($diff instanceof Sign){
					$line = $diff->getText();
					if($line[0] === TE::RED."[Elevator]"){
						$default = true;
					}
				}
			}
		}
		return $default;
	}
	
	/**
	 * @param String $singType
	 * @return null|String
	 */
	protected function getSignText(String $signType) : ?String {
		if($signType === "up"){
			return self::ELEVATOR_UP;
		}
		if($signType === "down"){
			return self::ELEVATOR_DOWN;
		}
		return self::ELEVATOR_UP;
	}
	
	/**
	 * @param Player $player
	 * @param Vector3 $position
	 * @param String $signType
	 */
	protected function teleportToSign(Player $player, Vector3 $position, String $signType = self::ELEVATOR_UP){
		if($this->isSign($signType, $position->getX(), $position->getY(), $position->getZ())){
			if($signType === self::ELEVATOR_UP){
				$location = $this->getTextUp($position->getX(), $position->getY(), $position->getZ());
				$player->teleport(new Vector3($position->getX() + 0.5, $location, $position->getZ() + 0.5, $player->getLevel()));
			}elseif($signType === self::ELEVATOR_DOWN){
				$location = $this->getTextDown($position->getX(), $position->getY(), $position->getZ());
				$player->teleport(new Vector3($position->getX() + 0.5, $location, $position->getZ() + 0.5, $player->getLevel()));
			}
		}
	}
}

?>