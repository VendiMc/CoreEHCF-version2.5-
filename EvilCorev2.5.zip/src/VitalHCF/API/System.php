<?php

namespace VitalHCF\API;

use VitalHCF\{Loader, Factions};
use VitalHCF\player\Player;

use pocketmine\event\Listener;
use pocketmine\utils\TextFormat as TE;
use pocketmine\math\Vector3;
use pocketmine\block\Block;
use pocketmine\item\{Item, ItemIds};

use pocketmine\network\mcpe\protocol\BlockActorDataPacket;
use pocketmine\network\mcpe\protocol\UpdateBlockPacket;

use RuntimeException;

class System {

    /** @var Array[] */
    protected static $cache = [];

    /**
     * @param Player $player
     * @param Vector3 $position
     * @param Block $block
     */
    public static function createTower(Player $player, Vector3 $position, Block $block){
        for($y = $position->y + 1; $y <= $position->y + 20; $y++){
            $pk = new UpdateBlockPacket();
			$pk->x = (int)$position->x;
			$pk->y = (int)$y;
			$pk->z = (int)$position->z;
			$pk->flags = UpdateBlockPacket::FLAG_ALL;
			$pk->blockRuntimeId = $block->getRuntimeId();
            $player->dataPacket($pk);
        }
    }

    /**
     * @param Player $player
     * @param Int $value
     */
    public static function deleteTower(Player $player, Int $value){
        if($value === 1){
        	if(self::isPosition($player, 1)){
      	  	$position = new Vector3(self::$cache[$player->getName()]["position1"][0], self::$cache[$player->getName()]["position1"][1], self::$cache[$player->getName()]["position1"][2]);
      		  self::createTower($player, $position, Block::get(Block::AIR));
    		}
   	 }elseif($value === 2){
        	if(self::isPosition($player, 2)){
      	  	$position = new Vector3(self::$cache[$player->getName()]["position2"][0], self::$cache[$player->getName()]["position2"][1], self::$cache[$player->getName()]["position2"][2]);
      		  self::createTower($player, $position, Block::get(Block::AIR));
    		}
   	 }
    }

    /**
     * @param Player $player
     * @param Int $position
     */
    public static function getPosition(Player $player, Int $position){
        if($position === 1){
            if(self::isPosition($player, 1)){
         	   return self::$cache[$player->getName()]["position1"];
        	}
        }
        if($position === 2){
            if(self::isPosition($player, 2)){
            	return self::$cache[$player->getName()]["position2"];
            }
        }
    }

    /**
     * @param Player $player
     * @param Int $position
     */
    public static function setPosition(Player $player, Vector3 $position, Int $positionId) : void {
        if($positionId === 1){
            self::$cache[$player->getName()]["position1"] = [$position->x, $position->y, $position->z];
        }
        if($positionId === 2){
            self::$cache[$player->getName()]["position2"] = [$position->x, $position->y, $position->z];
        }
    }

    /**
     * @param Player $player
     * @param Int $position
     * @return bool 
     */
    public static function isPosition(Player $player, Int $position) : bool {
    	if($position === 1){
      	  if(isset(self::$cache[$player->getName()]["position1"][0], self::$cache[$player->getName()]["position1"][1], self::$cache[$player->getName()]["position1"][2])){
       	     return true;
       	 }
        }
        if($position === 2){
        	if(isset(self::$cache[$player->getName()]["position2"][0], self::$cache[$player->getName()]["position2"][1], self::$cache[$player->getName()]["position2"][2])){
        		return true;
     	   }
        }
        return false;
    }

    /**
     * @param Player $player
     * @return void
     */
    public static function deletePosition(Player $player) : void {
        if(!isset(self::$cache[$player->getName()]["position1"]) and !isset(self::$cache[$player->getName()]["position2"])) return;
        $player->setInteract(false);
        $player->getInventory()->removeItem(Item::get(ItemIds::DIAMOND_HOE, 0, 1));
        unset(self::$cache[$player->getName()]["position1"]);
        unset(self::$cache[$player->getName()]["position2"]);
    }
    
    /**
     * @param Player $player
     * @param Array $position1
     * @param Array $position2
     * @return void
     */
    public static function checkClaim(Player $player, Array $position1, Array $position2) : void {
        if($player->isGodMode()){
            return;
        }
    	$xMin = min($position1[0], $position2[0]);
		$xMax = max($position1[0], $position2[0]);
		
		$zMin = min($position1[2], $position2[2]);
		$zMax = max($position1[2], $position2[2]);

        $distance1 = new Vector3($position1[0], 0, $position1[2]);
        $distance2 = new Vector3($position2[0], 0, $position2[2]);
        if((int)$distance1->distance($distance2) > 200){
            self::deleteTower($player, 1);
            self::deleteTower($player, 2);
        	self::deletePosition($player);
            $player->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_zone_is_big")));
            return;
        }
		for($x = $xMin; $x <= $xMax; ++$x){
			for($z = $zMin; $z <= $zMax; ++$z){
				$data = Loader::getProvider()->getDataBase()->query("SELECT * FROM zoneclaims WHERE $x >= x1 AND $x <= x2 AND $z >= z1 AND $z <= z2;");
				$result = $data->fetchArray(SQLITE3_ASSOC);
				if(!empty($result)){
				    self::deleteTower($player, 1);
         		    self::deleteTower($player, 2);
       		        self::deletePosition($player, 1);
           			self::deletePosition($player, 2);
           			$player->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_not_claim_other_zone")));
       	    		return;
       	 	    }
       	    }
        }
        $finalDistance = (int)$distance1->distance($distance2);
        $player->setClaimCost($finalDistance * 40);
        $player->sendMessage(str_replace(["&", "{claimCost}"], ["§", $player->getClaimCost()], Loader::getConfiguration("messages")->get("player_zone_cost")));
    }
}

?>