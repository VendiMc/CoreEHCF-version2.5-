<?php

namespace VitalHCF\item;

use VitalHCF\item\specials\{
	StormBreaker, AntiTrapper, NinjaShear,
};
use VitalHCF\item\netherite\{
	Helmet, Chestplate, Leggings, Boots, Sword, Pickaxe
};
use VitalHCF\block\{
	MonsterSpawner,
};

use pocketmine\block\BlockFactory;
use pocketmine\item\{Item, ItemFactory};

class Items {

	const NETHERITE_HELMET = 748, NETHERITE_CHESTPLATE = 749, NETHERITE_LEGGINGS = 750, NETHERITE_BOOTS = 751, NETHERITE_SWORD = 743, NETHERITE_PICKAXE = 745;
	
	/**
	 * @return void
	 */
	public static function init() : void {
		
		//ITEMS
		ItemFactory::registerItem(new EnderPearl(), true);
		ItemFactory::registerItem(new SplashPotion(), true);
		ItemFactory::registerItem(new GoldenApple(), true);
		ItemFactory::registerItem(new GoldenAppleEnchanted(), true);
		
		ItemFactory::registerItem(new StormBreaker(), true);
		ItemFactory::registerItem(new AntiTrapper(), true);
		ItemFactory::registerItem(new NinjaShear(), true);

		ItemFactory::registerItem(new Helmet(), true);
		ItemFactory::registerItem(new Chestplate(), true);
		ItemFactory::registerItem(new Leggings(), true);
		ItemFactory::registerItem(new Boots(), true);
		ItemFactory::registerItem(new Sword(), true);
		ItemFactory::registerItem(new Pickaxe(), true);
		
		//BLOCKS
		BlockFactory::registerBlock(new MonsterSpawner(), true);
	}

	/**
	 * @param Item $item
	 * @return Array[]
	 */
	public static function itemSerialize(Item $item) : Array {
		$data = $item->jsonSerialize();
		return $data;
	}

	/**
	 * @param Array[] $items
	 * @return Item
	 */
	public static function itemDeserialize(Array $items) : Item {
		$item = Item::jsonDeserialize($items);
		return $item;
	}
}

?>