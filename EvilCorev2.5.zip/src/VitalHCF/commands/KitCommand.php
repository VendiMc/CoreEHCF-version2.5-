<?php

namespace VitalHCF\commands;

use VitalHCF\Loader;
use VitalHCF\player\Player;

use VitalHCF\kit\{Kit, KitManager, KitBackup};

use pocketmine\command\{CommandSender, PluginCommand};
use pocketmine\utils\TextFormat as TE;

class KitCommand extends PluginCommand {
	
	/**
	 * KitCommand Constructor.
	 */
	public function __construct(){
		parent::__construct("kit", Loader::getInstance());
	}
	
	/**
	 * @param CommandSender $sender
	 * @param String $label
	 * @param Array $args
	 * @return void
	 */
	public function execute(CommandSender $sender, String $label, Array $args) : void {
		if(!$sender->isOp()){
			$sender->sendMessage(TE::RED."You have not permissions to use this command");
			return;
		}
		if(count($args) === 0){
			$sender->sendMessage(TE::RED."Use: /kit help (view list of commands)");
			return;
		}
		switch($args[0]){
			case "create":
				if(!$sender->isOp()){
					$sender->sendMessage(TE::RED."You have not permissions to use this command");
					return;
				}
				if(empty($args[1])||empty($args[2])||empty($args[3])){
					$sender->sendMessage(TE::RED."Use: /{$label} {$args[0]} <kitName> <kitPermission> <kitFormatName>");
					return;
				}
				if(KitManager::isKit($args[1])){
					$sender->sendMessage(str_replace(["&", "{kitName}"], ["§", $args[1]], Loader::getConfiguration("messages")->get("player_kit_alredy_exists")));
					return;
				}
				Loader::$kits[$args[1]] = new Kit($args[1], $sender->getInventory()->getContents(), $sender->getArmorInventory()->getContents(), $args[2], $args[3]);
				$sender->sendMessage(str_replace(["&", "{kitName}"], ["§", $args[1]], Loader::getConfiguration("messages")->get("player_kit_create_correctly")));
			break;
			case "delete":
				if(!$sender->isOp()){
					$sender->sendMessage(TE::RED."You have not permissions to use this command");
					return;
				}
				if(empty($args[1])){
					$sender->sendMessage(TE::RED."Use: /{$label} {$args[0]} <kitName>");
					return;
				}
				if(!KitManager::isKit($args[1])){
					$sender->sendMessage(str_replace(["&", "{kitName}"], ["§", $args[1]], Loader::getConfiguration("messages")->get("player_kit_not_exists")));
					return;
				}
				KitBackup::delete($args[1]);
				$sender->sendMessage(str_replace(["&", "{kitName}"], ["§", $args[1]], Loader::getConfiguration("messages")->get("player_kit_delete_correctly")));
			break;
			case "help":
			case "?":
			break;
		}
	}
}

?>