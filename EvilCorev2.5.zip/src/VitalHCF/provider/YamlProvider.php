<?php

namespace VitalHCF\provider;

use VitalHCF\Loader;
use VitalHCF\player\Player;

use pocketmine\utils\{Config, TextFormat as TE};
use pocketmine\Server;

class YamlProvider {
	
	const ONE_DAY = 1 * 86400;
	
	const THREE_HOURS = 3 * 3600;
	
	/**
	 * @return void
	 */
	public static function init() : void {
		Loader::getInstance()->saveResource("config.yml");
		Loader::getInstance()->saveResource("messages.yml");
		Loader::getInstance()->saveResource("CratesManager.yml");
		Loader::getInstance()->saveResource("scoreboard_settings.yml");
		if(!is_dir(Loader::getInstance()->getDataFolder())){
			@mkdir(Loader::getInstance()->getDataFolder());
		}
		if(!is_dir(Loader::getInstance()->getDataFolder()."players")){
			@mkdir(Loader::getInstance()->getDataFolder()."players");
		}
		if(!is_dir(Loader::getInstance()->getDataFolder()."backup")){
			@mkdir(Loader::getInstance()->getDataFolder()."backup");
		}
		Loader::getInstance()->getLogger()->info(TE::GREEN."YamlProvider » was loaded successfully!");
	}
	
	/**
	 * @param Player $player
	 * @return void
	 */
	public static function createConfig(Player $player, Int $defaultTime = self::THREE_HOURS, Int $defaultRewardTime = self::ONE_DAY, Int $defaultMoney = null) : void {
		new Config(Loader::getInstance()->getDataFolder()."players".DIRECTORY_SEPARATOR."{$player->getName()}.yml", Config::YAML, [
		"address" => $player->getAddress(),
		"reclaim_time" => (1 * 86400),
		"money_default" => $defaultMoney,
		"brewer_time" => (4 * 3600),
		]);
	}
	
	/**
	 * @param String $playerName
	 * @param String $data
	 * @param String $type
	 */
	public static function setData(String $playerName, $data, $type) : void {
		$config = new Config(Loader::getInstance()->getDataFolder()."players".DIRECTORY_SEPARATOR."{$playerName}.yml", Config::YAML);
		$config->set($data, $type);
		$config->save();
	}
	
	/**
	 * @param String $playerName
	 * @return String|Config
	 */
	public static function getData(String $playerName){
		return new Config(Loader::getInstance()->getDataFolder()."players".DIRECTORY_SEPARATOR."{$playerName}.yml", Config::YAML);
	}
	
	/**
	 * @param String $playerName
	 * @param String $configType
	 * @param String|Int $config
	 * @return void
	 */
	public static function reset(String $playerName, String $configType, $configSelect) : void {
		self::setData($playerName, $configType, $configSelect);
	}

	/**
	 * @param String $playerName
	 * @return Int|null
	 */
	public static function getBrewerTime(String $playerName) : ?Int {
		return self::getData($playerName)->get("brewer_time");
	}
	
	/**
	 * @param String $playerName
	 * @return Int|null
	 */
	public static function getMoney(String $playerName) : ?Int {
		return self::getData($playerName)->get("money_default");
	}
	
	/**
	 * @param String $playerName
	 * @param Int $money
	 * @return void
	 */
	public static function reduceMoney(String $playerName, Int $money) : void {
		self::setData($playerName, "money_default", self::getMoney($playerName) - $money);
	}

	/**
	 * @param String $playerName
	 * @param Int $money
	 * @return void
	 */
	public static function addMoney(String $playerName, Int $money) : void {
		self::setData($playerName, "money_default", self::getMoney($playerName) + $money);
	}
	
	/**
	 * @param String $playerName
	 * @param Int $money
	 * @return void
	 */
	public static function setMoney(String $playerName, Int $money) : void {
		self::setData($playerName, "money_default", $money);
	}

	/**
	 * @param String $playerName
	 * @param String $kitName
	 */
	public static function getKitTime(String $playerName, String $kitName){
		return self::getData($playerName)->get($kitName);
	}

	/**
	 * @param String $playerName
	 */
	public static function getReclaimTime(String $playerName){
		return self::getData($playerName)->get("reclaim_time");
	}

	/**
	 * @param String $playerName
	 * @param Int $kills
	 * @return void
	 */
	public static function setKills(String $playerName, Int $killsCount) : void {
		$kills = new Config(Loader::getInstance()->getDataFolder()."kills.yml", Config::YAML);
    	$kills->set($playerName, $killsCount);
    	$kills->save();
	}
	
	/**
	 * @param String $playerName
	 * @return Int|null
	 */
	public static function getKills(String $playerName){
		$kills = new Config(Loader::getInstance()->getDataFolder()."kills.yml", Config::YAML);
		return $kills->get($playerName);
	}
}

?>