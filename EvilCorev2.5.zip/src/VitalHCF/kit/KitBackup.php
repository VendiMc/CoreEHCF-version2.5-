<?php

namespace VitalHCF\kit;

use VitalHCF\Loader;
use VitalHCF\player\Player;

use VitalHCF\item\Items;

use pocketmine\utils\{Config, TextFormat as TE};

use RuntimeException;

class KitBackup {

    /**
     * @return void
     */
    public static function init() : void {
        $items = [];
        $armorItems = [];

        $data = new Config(Loader::getInstance()->getDataFolder()."backup".DIRECTORY_SEPARATOR."kits.yml", Config::YAML);
        foreach($data->getAll() as $kitName => $kit){
            $file = $data->getAll();
            $kitData = $file[$kitName];
            if(isset($kitData["items"])){
                foreach($kitData["items"] as $slot => $item){
                    $items[$slot] = Items::itemDeserialize($item);
                }
            }
            if(isset($kitData["armorItems"])){
                foreach($kitData["armorItems"] as $slot => $item){
                    $armorItems[$slot] = Items::itemDeserialize($item);
                }
            }
            Loader::$kits[$kitName] = new Kit($kitName, $items, $armorItems, $kitData["permission"], empty($kitData["kitNameFormat"]) ? null : $kitData["kitNameFormat"]);
        }
    }

    /**
     * @return void
     */
    public static function save() : void {
        $kitData = [];
        $file = new Config(Loader::getInstance()->getDataFolder()."backup".DIRECTORY_SEPARATOR."kits.yml", Config::YAML);
        foreach(KitManager::getKits() as $kit){
            $kitData["permission"] = $kit->getPermission();
            $kitData["kitNameFormat"] = $kit->getNameFormat();
            foreach($kit->getItems() as $slot => $item){
                $kitData["items"][$slot] = Items::itemSerialize($item);
            }
            foreach($kit->getArmorItems() as $slot => $item){
                $kitData["armorItems"][$slot] = Items::itemSerialize($item);
            }
            $file->set($kit->getName(), $kitData);
            $file->save();
        }
    }

    /**
     * @param String $kitName
     * @return void
     */
    public static function delete(String $kitName) : void {
        $file = new Config(Loader::getInstance()->getDataFolder()."backup".DIRECTORY_SEPARATOR."kits.yml", Config::YAML);
        $file->remove($kitName);
        $file->save();
        unset(Loader::$kits[$kitName]);
    }
}

?>