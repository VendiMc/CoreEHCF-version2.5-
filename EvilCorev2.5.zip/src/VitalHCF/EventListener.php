<?php

namespace VitalHCF;

use VitalHCF\{Loader, Factions};
use VitalHCF\player\Player;

use VitalHCF\Task\Scoreboard;

use VitalHCF\AsyncTask\PlayerData;

use VitalHCF\provider\YamlProvider;

use pocketmine\event\Listener;
use pocketmine\math\Vector3;
use pocketmine\utils\TextFormat as TE;

use pocketmine\event\player\{PlayerJoinEvent, PlayerQuitEvent, PlayerChatEvent, PlayerMoveEvent, PlayerInteractEvent};
use pocketmine\event\player\PlayerCreationEvent;
use pocketmine\event\entity\EntityLevelChangeEvent;

class EventListener implements Listener {

    /** @var Loader */
    protected $plugin;

    /**
     * EventListener Constructor.
     * @param Loader $plugin
     */
    public function __construct(Loader $plugin){
        $this->plugin = $plugin;
    }

    /**
     * @param PlayerCreationEvent $event
     * @return void
     */
    public function onPlayerCreationEvent(PlayerCreationEvent $event) : void {
        $event->setPlayerClass(Player::class, true);
    }

    /**
     * @param PlayerJoinEvent $event
     * @return void
     */
    public function onPlayerJoinEvent(PlayerJoinEvent $event) : void {
        $player = $event->getPlayer();
        $event->setJoinMessage(TE::GRAY."[".TE::GREEN."+".TE::GRAY."] ".TE::GREEN.$player->getName().TE::GRAY." entered the server!");
        
        //TODO:
        $this->plugin->getScheduler()->scheduleRepeatingTask(new Scoreboard($player), 20);
        
		YamlProvider::createConfig($player);
		$player->showCoordinates();
    }

    /**
     * @param PlayerQuitEvent $event
     * @return void
     */
    public function onPlayerQuitEvent(PlayerQuitEvent $event) : void {
        $player = $event->getPlayer();
		$event->setQuitMessage(TE::GRAY."[".TE::RED."-".TE::GRAY."] ".TE::RED.$player->getName().TE::GRAY." left the server!");
	}
	
	/**
     * @param EntityLevelChangeEvent $event
     * @return void
     */
	public function onEntityLevelChangeEvent(EntityLevelChangeEvent $event) : void {
		$player = $event->getEntity();
		$player->showCoordinates();
	}
	
	/**
     * @param PlayerChatEvent $event
     * @return void
     */
    public function onPlayerChatEvent(PlayerChatEvent $event) : void {
    	$player = $event->getPlayer();
    	if(Factions::inFaction($player->getName())){
			$factionName = Factions::getFaction($player->getName());
			$event->setFormat(TE::GOLD."[".TE::RED.$factionName.TE::GOLD."]".TE::RESET.$player->getName().": ".$event->getMessage(), true);
		}else{
			$event->setFormat($player->getName().": ".$event->getMessage(), true);
		}
	}
}

?>