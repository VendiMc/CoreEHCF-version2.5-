<?php

namespace VitalHCF\listeners\interact;

use VitalHCF\Loader;
use VitalHCF\player\Player;

use pocketmine\event\Listener;
use pocketmine\utils\{Config, TextFormat as TE};
use pocketmine\math\Vector3;
use pocketmine\item\{ItemFactory, Item};
use pocketmine\tile\Sign;

use pocketmine\event\block\{BlockBreakEvent, SignChangeEvent};
use pocketmine\block\{SignPost, WallSign};
use pocketmine\event\player\PlayerInteractEvent;

class Shop implements Listener {
	
	const SHOP = "Shop", SELL = "Sell";
	
	/** @var Loader */
	protected $plugin;
	
	/** @var array */
	protected $sign = [];
	
	/**
	 *  Shop Constructor.
	 * @param Loader $plugin
	 */
	public function __construct(Loader $plugin){
		$this->plugin = $plugin;
		$this->sign = (new Config($plugin->getDataFolder()."backup".DIRECTORY_SEPARATOR."shops.yml", Config::YAML))->getAll();
	}
	
	/**
	 * @param String $shopType
	 * @param Int $itemID
	 * @param Int $itemDamage
	 * @param Int $itemAmount
	 * @param Int $itemPrice
	 * @param Vector3 $block
	 */
	public function createShop(String $shopType = self::SHOP, Int $itemID, Int $itemDamage, Int $itemAmount, Int $itemPrice, Vector3 $block, String $signName = null){
		$this->sign[$block->getX().":".$block->getY().":".$block->getZ()] = [
			"sign_name" => $signName, 
			"type" => $shopType, 
			"item_id" => $itemID, 
			"item_damage" => $itemDamage, 
			"item_amount" => $itemAmount, 
			"price" => $itemPrice,
		];
		$config = new Config($this->plugin->getDataFolder()."backup".DIRECTORY_SEPARATOR."shops.yml", Config::YAML);
		$config->setAll($this->sign);
		$config->save();
	}
	
	/**
	 * @param PlayerInteractEvent $event
	 * @return void
	 */
	public function onInteractEvent(PlayerInteractEvent $event) : void {
		$player = $event->getPlayer();
		$block = $event->getBlock();
		$sign = $player->getLevel()->getTile($block);
		if($block instanceof SignPost||$block instanceof WallSign){
			if(isset($this->sign[$block->getX().":".$block->getY().":".$block->getZ()])){
				$shop = $this->sign[$block->getX().":".$block->getY().":".$block->getZ()];
				if($shop["type"] === self::SELL){
					if($player->getInventory()->contains($item = Item::get($shop["item_id"], $shop["item_damage"], $shop["item_amount"]))){
						$player->getInventory()->removeItem($item);
						$player->addBalance($shop["price"]);
						$player->sendMessage(TE::GREEN."You have successfully sold ".TE::YELLOW.$item->getName());
					}else{
						$player->sendMessage(TE::RED."You don't have that item!");
					}
				}
				if($shop["type"] === self::SHOP){
					if($player->getBalance() < $shop["price"]){
						$player->sendMessage(TE::RED."You don't have enough of money!");
						$event->setCancelled(true);
						return;
					}
					if(!$player->getInventory()->canAddItem(ItemFactory::get($shop["item_id"], $shop["item_damage"]))){
						$player->sendMessage(TE::RED."Your inventory is full!");
						$event->setCancelled(true);
						return;
					}
					$item = Item::get($shop["item_id"], $shop["item_damage"], $shop["item_amount"]);
					$player->getInventory()->addItem($item);
					$player->reduceBalance($shop["price"]);
					$player->sendMessage(TE::GREEN."You have successfully purchased ".TE::YELLOW.$item->getName());
				}
			}
		}
	}
	
	/**
	 * @param BlockBreakEvent $event
	 * @return void
	 */
	public function onBlockBreak(BlockBreakEvent $event) : void {
		$player = $event->getPlayer();
		$block = $event->getBlock();
		if(isset($this->sign[$block->getX().":".$block->getY().":".$block->getZ()])){
			if($player->isOp()){
				unset($this->sign[$block->getX().":".$block->getY().":".$block->getZ()]);
				$config = new Config($this->plugin->getDataFolder()."backup".DIRECTORY_SEPARATOR."shops.yml", Config::YAML);
				$config->remove($block->getX().":".$block->getY().":".$block->getZ());
				$config->save();
				$player->sendMessage(TE::GREEN."You successfully removed the sign");
			}
		}
	}
	
	/**
	 * @param SignChangeEvent $event
	 * @return void
	 */
	public function onSignChangeEvent(SignChangeEvent $event) : void {
		$player = $event->getPlayer();
		if($player->isOp()){
			$block = $event->getBlock();
			if($event->getLine(0) == "" || $event->getLine(1) == "" || $event->getLine(2) == "" || $event->getLine(3) == "") return;
			$item = Item::fromString($event->getLine(1));
			if(strtolower($event->getLine(0)) === "buy"){
				$this->createShop(self::SHOP, $item->getId(), $item->getDamage(), $event->getLine(2), $event->getLine(3), $block->asVector3());
				$event->setLine(0, TE::GREEN."[Shop]");
				$event->setLine(1, TE::BLACK.$item->getName());
				$event->setLine(2, TE::BLACK."x".$event->getLine(2));
				$event->setLine(3, TE::BLACK."$".$event->getLine(3));
			}elseif(strtolower($event->getLine(0)) === "sell"){
				$this->createShop(self::SELL, $item->getId(), $item->getDamage(), $event->getLine(2), $event->getLine(3), $block->asVector3());
				$event->setLine(0, TE::RED."[Sell]");
				$event->setLine(1, TE::BLACK.$item->getName());
				$event->setLine(2, TE::BLACK."x".$event->getLine(2));
				$event->setLine(3, TE::BLACK."$".$event->getLine(3));
			}
		}
	}
}

?>