<?php

namespace VitalHCF\commands;

use VitalHCF\{Loader, Factions};
use VitalHCF\player\Player;

use VitalHCF\provider\YamlProvider;

use VitalHCF\API\System;

use VitalHCF\Task\{InvitationTask, TeleportHomeTask, TeleportStuckTask};

use pocketmine\utils\TextFormat as TE;
use pocketmine\level\Level;
use pocketmine\math\Vector3;
use pocketmine\block\Block;

use pocketmine\command\{PluginCommand, CommandSender};

class FactionCommand extends PluginCommand {

    /**
     * FactionCommand Constructor.
     */
    public function __construct(){
        parent::__construct("f", Loader::getInstance());
        $this->setDescription("Use: /f (view list of commands)");
    }

    /**
	 * @param CommandSender $sender
	 * @param String $label
	 * @param Array $args
	 * @return void
	 */
	public function execute(CommandSender $sender, String $label, Array $args) : void {
        $senderName = $sender->getName();
        if(count($args) === 0){
            $sender->sendMessage(
				TE::YELLOW."/{$label} create <factionName> ".TE::GRAY."(With this command you can create your new faction)"."\n".
				TE::YELLOW."/{$label} disband ".TE::GRAY."(With this command you can erase your faction)"."\n".
				TE::YELLOW."/{$label} leave ".TE::GRAY."(With this command you can exit a faction)"."\n".
				TE::YELLOW."/{$label} invite <playerName> ".TE::GRAY."(With this command you can invite members to your faction)"."\n".
				TE::YELLOW."/{$label} kick <playerName> ".TE::GRAY."(Use this command to remove players from your faction)"."\n".
				TE::YELLOW."/{$label} claim ".TE::GRAY."(With this command you can claim your land)"."\n".
				TE::YELLOW."/{$label} chat <public:faction> ".TE::GRAY."(Select in which chat to speak)"."\n".
				TE::YELLOW."/{$label} unclaim ".TE::GRAY."(With this command you can delete the area of your claim)"."\n".
				TE::YELLOW."/{$label} sethome ".TE::GRAY."(Place the home of your faction)"."\n".
				TE::YELLOW."/{$label} deposit <amount:all> ".TE::GRAY."(Deposit the money in your faction)"."\n".
                TE::YELLOW."/{$label} withdraw <amount:all> ".TE::GRAY."(Can take money out of your faction)"."\n".
                TE::YELLOW."/{$label} who <factionName:playerName> ".TE::GRAY."(View enemy faction information)"
			);
            return;
        }
        switch($args[0]){
            case "dtrall":
                if(!$sender->hasPermission("faction.command.use")){
					$sender->sendMessage(TE::RED."You have not permissions to use this command");
					return;
                }
                foreach(Factions::getAllFactions() as $factionName){
                    Factions::setStrength($factionName, Factions::getMaxStrength($factionName));
                }
            break;
            case "freezeall":
               if(!$sender->hasPermission("faction.command.use")){
					$sender->sendMessage(TE::RED."You have not permissions to use this command");
					return;
                }
                foreach(Factions::getAllFactions() as $factionName){
                    Factions::removeFreezeTime($factionName);
                }
            break;
            case "disbandall":
                if(!$sender->hasPermission("faction.command.use")){
					$sender->sendMessage(TE::RED."You have not permissions to use this command");
					return;
                }
                foreach(Factions::getAllFactions() as $factionName){
                    Factions::deleteFaction($factionName);
                }
            break;
            case "opclaim":
                if(!$sender->hasPermission("faction.command.use")){
					$sender->sendMessage(TE::RED."You have not permissions to use this command");
					return;
				}
                if(empty($args[1])){
                    $sender->addTool();
                    $sender->setInteract(true);
                }else{
                    if(!System::isPosition($sender, 1) and !System::isPosition($sender, 2)){
                        $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_not_zone_location")));
                        return;
                    }
                    if(Factions::isRegionExists($args[1])){
                        $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_zone_exists")));
                        return;
                    }
                    if($args[1] === "Spawn"){
                        Factions::claimRegion($args[1], $sender->getLevel()->getName(), System::getPosition($sender, 1), System::getPosition($sender, 2), Factions::SPAWN);
                        System::deleteTower($sender, 1);
                        System::deleteTower($sender, 2);
                        System::deletePosition($sender);
                    }else{
                        Factions::claimRegion($args[1], $sender->getLevel()->getName(), System::getPosition($sender, 1), System::getPosition($sender, 2), Factions::PROTECTION);
                        System::deleteTower($sender, 1);
                        System::deleteTower($sender, 2);
                        System::deletePosition($sender);
                    }
                }
            break;
            case "forcedisband":
                if(!$sender->hasPermission("faction.command.use")){
					$sender->sendMessage(TE::RED."You have not permissions to use this command");
					return;
				}
                if(empty($args[1])){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("faction_forcedisband_help")));
                    return;
                }
                if(!Factions::isFaction($args[1])){
                    $sender->sendMessage(str_replace(["&", "{factionName}"], ["§", $args[1]], Loader::getConfiguration("messages")->get("faction_not_exists")));
                    return;
                }
                Factions::deleteFaction($args[1], $sender);
            break;
            case "setdtr":
                if(!$sender->hasPermission("faction.command.use")){
					$sender->sendMessage(TE::RED."You have not permissions to use this command");
					return;
				}
                if(empty($args[1])||empty($args[2])){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("faction_setdtr_help")));
                    return;
                }
                if(!is_string($args[1])){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_not_is_string")));
                    return;
                }
                if(!is_numeric($args[2])){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_not_is_numeric")));
                    return;
                }
                Factions::setStrength($args[1], $args[2]);
            break;
            case "setbalance":
                if(!$sender->hasPermission("faction.command.use")){
					$sender->sendMessage(TE::RED."You have not permissions to use this command");
					return;
				}
                if(empty($args[1])||empty($args[2])){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("faction_setbalance_help")));
                    return;
                }
                if(!is_string($args[1])){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_not_is_string")));
                    return;
                }
                if(!is_numeric($args[2])){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_not_is_numeric")));
                    return;
                }
                Factions::setBalance($args[1], $args[2]);
            break;
            case "forceleave":
                if(!$sender->hasPermission("faction.command.use")){
					$sender->sendMessage(TE::RED."You have not permissions to use this command");
					return;
				}
                if(empty($args[1])||empty($args[2])){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("faction_forceleave_help")));
                    return;
                }
                if(!is_string($args[1])||!is_string($args[2])){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_not_is_string")));
                    return;
                }
                if(Factions::getLeader($args[2]) === $args[1]){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("faction_forceleave_is_leader")));
                    return;
                }
                Factions::removeToFaction($args[1]);
            break;
            case "create":
                if(Factions::inFaction($senderName)){
                    $sender->sendMessage(str_replace(["&", "{factionName}"], ["§", Factions::getFaction($senderName)], Loader::getConfiguration("messages")->get("player_in_faction")));
                    return;
                }
                if(empty($args[1])){
                    $sender->sendMessage(TE::RED."Use: /{$label} {$args[0]} <factionName>");
                    return;
                }
                if(!is_string($args[1])){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_not_is_string")));
                    return;
                }
                if(strlen($args[1]) >= 15){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_big_format")));
                    return;
                }
                if(strlen($args[1]) < 5){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_small_format")));
                    return;
                }
                Factions::createNewFaction($args[1], $sender);
            break;
            case "disband":
                if(!Factions::inFaction($senderName)){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_not_in_faction")));
                    return;
                }
                if(Factions::getStrength(Factions::getFaction($senderName)) < 1){
                	$sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("faction_is_raid")));
                	return;
                }
                if(Factions::getLeader(Factions::getFaction($senderName)) !== $senderName){
                	$sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_is_not_leader")));
                	return;
                }
                Factions::deleteFaction(Factions::getFaction($senderName));
            break;
            case "leave":
                if(!Factions::inFaction($senderName)){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_not_in_faction")));
                    return;
                }
                if(Factions::getLeader(Factions::getFaction($senderName)) === $senderName){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_is_leader")));
                    return;
                }
                if(Factions::getStrength(Factions::getFaction($senderName)) < 1){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("faction_is_raid")));
                    return;
                }
                $sender->sendMessage(str_replace(["&", "{factionName}"], ["§", Factions::getFaction($senderName)], Loader::getConfiguration("messages")->get("player_leave_correctly")));
                Factions::removeToFaction($senderName);
            break;
            case "claim":
                if(!Factions::inFaction($senderName)){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_not_in_faction")));
                    return;
                }
                if(Factions::getLeader(Factions::getFaction($senderName)) !== $senderName){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_is_not_leader")));
                    return;
                }
                if(Factions::isRegionExists(Factions::getFaction($senderName))){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_zone_exists")));
                    return;
                }
                if($sender->isInteract()){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_is_zone_mode")));
                    return;
                }
                $sender->setInteract(true);
                $sender->addTool();
                $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_zone_help")));
            break;
            case "unclaim":
                if($sender->isOp() && !empty($args[1])){
                    Factions::deleteRegion($args[1]);
                    return;
                }
                if(!Factions::inFaction($senderName)){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_not_in_faction")));
                    return;
                }
                if(Factions::getLeader(Factions::getFaction($senderName)) !== $senderName){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_is_not_leader")));
                    return;
                }
                if(Factions::getStrength(Factions::getFaction($senderName)) < 1){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("faction_is_raid")));
                    return;
                }
                if(!Factions::isRegionExists(Factions::getFaction($senderName))){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_zone_not_exists")));
                    return;
                }
                Factions::deleteRegion(Factions::getFaction($senderName));
                $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_zone_delete_correctly")));
            break;
            case "map":
                if($sender->isOp() && !empty($args[1])){
                    if(!$sender->isViewingMap()){
                        Factions::observeMap($sender, Block::get(Block::GLASS), $args[1], true);
                        $sender->setViewingMap(true);
                        $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_see_zone")));
                    }else{
                        Factions::observeMap($sender, Block::get(Block::AIR), $args[1], true);
                        $sender->setViewingMap(false);
                        $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_hide_zone")));
                    }
                    return;
                }
                if(!Factions::inFaction($senderName)){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_not_in_faction")));
                    return;
                }
                if(!Factions::isRegionExists(Factions::getFaction($senderName))){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_zone_not_exists")));
                    return;
                }
                if(!$sender->isViewingMap()){
                    Factions::observeMap($sender, Block::get(Block::GLASS));
                    $sender->setViewingMap(true);
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_see_zone")));
                }else{
                    Factions::observeMap($sender, Block::get(Block::AIR));
                    $sender->setViewingMap(false);
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_hide_zone")));
                }
            break;
            case "sethome":
                if(!Factions::inFaction($senderName)){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_not_in_faction")));
                    return;
                }
                if(Factions::getLeader(Factions::getFaction($senderName)) !== $senderName){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_is_not_leader")));
                    return;
                }
                if(Factions::getRegionName($sender) !== Factions::getFaction($senderName)){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_is_not_in_your_zone")));
                    return;
                }
                Factions::setFactionHome(Factions::getFaction($senderName), $sender);
                foreach(Factions::getPlayers(Factions::getFaction($senderName)) as $player){
                    $online = Loader::getInstance()->getServer()->getPlayer($player);
                    if($online instanceof Player){
                        $online->sendMessage(str_replace(["&", "{playerName}"], ["§", $senderName], Loader::getConfiguration("messages")->get("player_place_home")));
                    }
                }
            break;
            case "home":
                if(!Factions::inFaction($senderName)){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_not_in_faction")));
                    return;
                }
                if(!Factions::isHome(Factions::getFaction($senderName))){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_home_not_exists")));
                    return;
                }
                if($sender->isTeleportingHome()){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_is_in_teleport_time")));
                    return;
                }
                if($sender->isCombatTag()){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_is_combatTag")));
                    return;
                }
                if(Factions::isSpawnRegion($sender)){
                	$sender->teleport(Factions::getFactionHomeLocation(Factions::getFaction($sender->getName())));
                	return;
                }
                $sender->setTeleportingHome(true);
                $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_got_to_home_help")));
                Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new TeleportHomeTask($sender), 20);
            break;
            case "stuck":
            	if(Factions::isSpawnRegion($sender)){
            		return;
            	}
                if($sender->isTeleportingStuck()){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_is_in_teleport_time")));
                    return;
                }
                $sender->setTeleportingStuck(true);
                $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_got_to_stuck_help")));
                Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new TeleportStuckTask($sender), 20);
            break;
            case "invite":
                if(!Factions::inFaction($senderName)){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_not_in_faction")));
                    return;
                }
                if(Factions::getLeader(Factions::getFaction($senderName)) !== $senderName){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_is_not_leader")));
                    return;
                }
                if(empty($args[1])){
                    $sender->sendMessage(TE::RED."Use: /{$label} {$args[0]} <playerName>");
                    return;
                }
                $player = Loader::getInstance()->getServer()->getPlayer($args[1]);
                if($player === null){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_not_is_online")));
                    return;
                }
                if(Factions::inFaction($player->getName())){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_is_already_in_faction")));
                    return;
                }
                if($player->getName() === $senderName){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_do_not_invite_yourself")));
                    return;
                }
                if($player->isInvited()){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_is_already_invited")));
                    return;
                }
                $player->setInvite(true);
                $player->setCurrentInvite(Factions::getFaction($senderName));
                $player->sendMessage(str_replace(["&", "{factionName}"], ["§", Factions::getFaction($senderName)], Loader::getConfiguration("messages")->get("player_invite_correctly")));
                Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new InvitationTask($player), 20);
            break;
            case "accept":
                if(Factions::inFaction($senderName)){
                    $sender->sendMessage(str_replace(["&", "{factionName}"], ["§", Factions::getFaction($senderName)], Loader::getConfiguration("messages")->get("player_in_faction")));
                    return;
                }
                if(!$sender->isInvited()){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_has_not_pending_invitations")));
                    return;
                }
                if(Factions::getMaxPlayers($sender->getCurrentInvite()) === Loader::getDefaultConfig("FactionsConfig")["maxPlayers"]){
                    $sender->sendMessage(str_replace(["&", "{factionName}"], ["§", $sender->getCurrentInvite()], Loader::getConfiguration("messages")->get("faction_is_full")));
                    return;
                }
                $sender->setInvite(false);
                Factions::addToFaction($senderName, $sender->getCurrentInvite(), Player::MEMBER);
            break;
            case "deny":
                if(Factions::inFaction($senderName)){
                    $sender->sendMessage(str_replace(["&", "{factionName}"], ["§", Factions::getFaction($senderName)], Loader::getConfiguration("messages")->get("player_in_faction")));
                    return;
                }
                if(!$sender->isInvited()){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_has_not_pending_invitations")));
                    return;
                }
                $sender->setInvite(false);
                $sender->sendMessage(str_replace(["&", "{factionName}"], ["§", $sender->getCurrentInvite()], Loader::getConfiguration("messages")->get("player_decline_invitation_correctly")));
            break;
            case "kick":
                if(!Factions::inFaction($senderName)){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_not_in_faction")));
                    return;
                }
                if(empty($args[1])){
                    $sender->sendMessage(TE::RED."Use: /{$label} {$args[0]} <playerName>");
                    return;
                }
                $player = Loader::getInstance()->getServer()->getPlayer($args[1]);
                if($player instanceof Player){
                	if(Factions::getLeader(Factions::getFaction($senderName)) !== $senderName){
	                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_is_not_leader")));
	                    return;
	                }
	                if(!Factions::inFaction($player->getName())){
	                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_is_not_in_faction")));
	                    return;
	                }
	                if(Factions::getFaction($player->getName()) !== Factions::getFaction($senderName)){
	                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_no_kick_other_factions")));
	                    return;
	                }
	                if(Factions::getLeader(Factions::getFaction($senderName)) === $player->getName()){
	                	$sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_not_kick_leader")));
	                	return;
	                }
	                Factions::removeToFaction($player->getName());
                }else{
	                if(Factions::getLeader(Factions::getFaction($senderName)) !== $senderName){
	                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_is_not_leader")));
	                    return;
	                }
	                if(!Factions::inFaction($args[1])){
	                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_is_not_in_faction")));
	                    return;
	                }
	                if(Factions::getFaction($args[1]) !== Factions::getFaction($senderName)){
	                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_no_kick_other_factions")));
	                    return;
	                }
	                if(Factions::getLeader(Factions::getFaction($senderName)) === $args[1]){
	                	$sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_not_kick_leader")));
	                	return;
	                }
	                Factions::removeToFaction($args[1]);
				}
            break;
            case "deposit":
            case "d":
                if(!Factions::inFaction($senderName)){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_not_in_faction")));
                    return;
                }
                if(empty($args[1])){
                    $sender->sendMessage(TE::RED."Use /{$label} {$args[0]} <amount:all>");
                    return;
                }
                if($args[1] === "all"){
                    if($sender->getBalance() === 0){
                        $sender->sendMessage(str_replace(["&", "{money}"], ["§", $sender->getBalance()], Loader::getConfiguration("messages")->get("player_has_not_money")));
                        return;
                    }
                    Factions::addBalance(Factions::getFaction($senderName), $sender->getBalance());
                    foreach(Factions::getPlayers(Factions::getFaction($senderName)) as $player){
                        $online = Loader::getInstance()->getServer()->getPlayer($player);
                        if($online instanceof Player){
                            $online->sendMessage(str_replace(["&", "{playerName}", "{money}"], ["§", $senderName, $sender->getBalance()], Loader::getConfiguration("messages")->get("player_deposit_money")));
                        }
                    }
                    $sender->reduceBalance($sender->getBalance());
                }else{
                    if(!is_numeric($args[1])){
                        $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_not_is_numeric")));
                        return;
                    }
                    if($sender->getBalance() < $args[1]){
                        $sender->sendMessage(str_replace(["&", "{money}"], ["§", $sender->getBalance()], Loader::getConfiguration("messages")->get("player_has_not_money")));
                        return;
                    }
                    Factions::addBalance(Factions::getFaction($senderName), $args[1]);
                    foreach(Factions::getPlayers(Factions::getFaction($senderName)) as $player){
                        $online = Loader::getInstance()->getServer()->getPlayer($player);
                        if($online instanceof Player){
                            $online->sendMessage(str_replace(["&", "{playerName}", "{money}"], ["§", $senderName, $args[1]], Loader::getConfiguration("messages")->get("player_deposit_money")));
                        }
                    }
                    $sender->reduceBalance($args[1]);
                }
            break;
            case "withdraw":
            case "w":
                if(!Factions::inFaction($senderName)){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_not_in_faction")));
                    return;
                }
                if(empty($args[1])){
                    $sender->sendMessage(TE::RED."Use /{$label} {$args[0]} <amount:all>");
                    return;
                }
                if($args[1] === "all"){
                    if(Factions::getBalance(Factions::getFaction($senderName)) === 0){
                        $sender->sendMessage(str_replace(["&", "{money}"], ["§", Factions::getBalance(Factions::getFaction($senderName))], Loader::getConfiguration("messages")->get("player_has_not_money")));
                        return;
                    }
                    $sender->addBalance(Factions::getBalance(Factions::getFaction($senderName)));
                    foreach(Factions::getPlayers(Factions::getFaction($senderName)) as $player){
                        $online = Loader::getInstance()->getServer()->getPlayer($player);
                        if($online instanceof Player){
                            $online->sendMessage(str_replace(["&", "{playerName}", "{money}"], ["§", $senderName, Factions::getBalance(Factions::getFaction($senderName))], Loader::getConfiguration("messages")->get("player_withdraw_money")));
                        }
                    }
                    Factions::reduceBalance(Factions::getFaction($senderName), Factions::getBalance(Factions::getFaction($senderName)));
                }else{
                    if(!is_numeric($args[1])){
                        $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_not_is_numeric")));
                        return;
                    }
                    if(Factions::getBalance(Factions::getFaction($senderName)) < $args[1]){
                        $sender->sendMessage(str_replace(["&", "{money}"], ["§", Factions::getBalance(Factions::getFaction($senderName))], Loader::getConfiguration("messages")->get("player_has_not_money")));
                        return;
                    }
                    $sender->addBalance($args[1]);
                    foreach(Factions::getPlayers(Factions::getFaction($senderName)) as $player){
                        $online = Loader::getInstance()->getServer()->getPlayer($player);
                        if($online instanceof Player){
                            $online->sendMessage(str_replace(["&", "{playerName}", "{money}"], ["§", $senderName, $args[1]], Loader::getConfiguration("messages")->get("player_withdraw_money")));
                        }
                    }
                    Factions::reduceBalance(Factions::getFaction($senderName), $args[1]);
                }
            break;
            case "chat":
            case "c":
                if(!Factions::inFaction($senderName)){
                    $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_not_in_faction")));
                	return;
                }
                if(empty($args[1])){
                    $sender->sendMessage(TE::RED."Use /{$label} {$args[0]} <public:faction>");
                    return;
                }
                switch($args[1]){
                	case "faction":
                	case "f":
                    	$sender->setChat(Player::FACTION_CHAT);
                	    $sender->sendMessage(str_replace(["&", "{currentChat}"], ["§", $sender->getChat()], Loader::getConfiguration("messages")->get("player_change_chat")));
                	break;
                	case "public":
                	case "p":
              	      $sender->setChat(Player::PUBLIC_CHAT);
          	          $sender->sendMessage(str_replace(["&", "{currentChat}"], ["§", $sender->getChat()], Loader::getConfiguration("messages")->get("player_change_chat")));
          	  	break;
                }
            break;
            case "rally":
            break;
            case "who":
            case "info":
                if(empty($args[1])){
                	if(!Factions::inFaction($senderName)){
                    	$sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_not_in_faction")));
                	    return;
                    }
                    $homeLocation = Factions::getFactionHomeString(Factions::getFaction($senderName));
                	$dtr = Factions::getStrength(Factions::getFaction($senderName));
                    $balance = Factions::getBalance(Factions::getFaction($senderName)) === null ? "$0" : "$".Factions::getBalance(Factions::getFaction($senderName));
                    $players = Factions::getMaxPlayers(Factions::getFaction($senderName)) === null ? "Error 404 report in discord" : Factions::getMaxPlayers(Factions::getFaction($senderName));
	                $maxPlayers = Loader::getDefaultConfig("FactionsConfig")["maxPlayers"];
                    $onlinePlayers = Factions::getListPlayers(Factions::getFaction($senderName)) === null ? "No members connected" : Factions::getListPlayers(Factions::getFaction($senderName));
                    $leader = Factions::getLeader(Factions::getFaction($senderName)) === null ? "Error 404 report in discord" : Factions::getLeader(Factions::getFaction($senderName)).TE::YELLOW."[".TE::GREEN.YamlProvider::getKills(Factions::getLeader(Factions::getFaction($senderName))).TE::YELLOW."]";
	                $co_leader = Factions::getCoLeader(Factions::getFaction($senderName)) === null ? "There is no co-leader" : Factions::getCoLeader(Factions::getFaction($senderName)).TE::YELLOW."[".TE::GREEN.YamlProvider::getKills(Factions::getLeader(Factions::getFaction($senderName))).TE::YELLOW."]";
	                $timeRegen = Factions::getFreezeTime(Factions::getFaction($senderName)) === null ? "Null" : Loader::getTimeToString(Factions::getFreezeTime(Factions::getFaction($senderName)));
                    
                    $sender->sendMessage(str_replace(["&", "{home}", "{factionName}", "{onlinePlayers}", "{players}", "{maxPlayers}", "{dtr}", "{leader}", "{co_leader}", "{balance}", "{timeRegen}", "%n%"], ["§", $homeLocation, Factions::getFaction($senderName), $onlinePlayers, $players, $maxPlayers, $dtr, $leader, $co_leader, $balance, $timeRegen, "\n"], Loader::getConfiguration("messages")->get("faction_information")));
                }else{
                	$player = Loader::getInstance()->getServer()->getPlayer($args[1]);
                	if($player instanceof Player){
                		if(!Factions::inFaction($player->getName())){
                			$sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("player_is_not_in_faction")));
                			return;
                        }	
                        $homeLocation = Factions::getFactionHomeString(Factions::getFaction($player->getName()));
                		$dtr = Factions::getStrength(Factions::getFaction($player->getName()));
	                    $balance = Factions::getBalance(Factions::getFaction($player->getName())) === null ? "$0" : "$".Factions::getBalance(Factions::getFaction($player->getName()));
	                    $players = Factions::getMaxPlayers(Factions::getFaction($player->getName())) === null ? "Error 404 report in discord" : Factions::getMaxPlayers(Factions::getFaction($player->getName()));
	                    $maxPlayers = Loader::getDefaultConfig("FactionsConfig")["maxPlayers"];
	                    $onlinePlayers = Factions::getListPlayers(Factions::getFaction($player->getName())) === null ? "No members connected" : Factions::getListPlayers(Factions::getFaction($player->getName()));
	                    $leader = Factions::getLeader(Factions::getFaction($player->getName())) === null ? "Error 404 report in discord" : Factions::getLeader(Factions::getFaction($player->getName())).TE::YELLOW."[".TE::GREEN.YamlProvider::getKills(Factions::getLeader(Factions::getFaction($player->getName()))).TE::YELLOW."]";
	                    $co_leader = Factions::getCoLeader(Factions::getFaction($player->getName())) === null ? "There is no co-leader" : Factions::getCoLeader(Factions::getFaction($player->getName())).TE::YELLOW."[".TE::GREEN.YamlProvider::getKills(Factions::getLeader(Factions::getFaction($player->getName()))).TE::YELLOW."]";
	                    $timeRegen = Factions::getFreezeTime(Factions::getFaction($player->getName())) === null ? "Null" : Loader::getTimeToString(Factions::getFreezeTime(Factions::getFaction($player->getName())));
	
	                    $sender->sendMessage(str_replace(["&", "{home}", "{factionName}", "{onlinePlayers}", "{players}", "{maxPlayers}", "{dtr}", "{leader}", "{co_leader}", "{balance}", "{timeRegen}", "%n%"], ["§", $homeLocation, Factions::getFaction($player->getName()), $onlinePlayers, $players, $maxPlayers, $dtr, $leader, $co_leader, $balance, $timeRegen, "\n"], Loader::getConfiguration("messages")->get("faction_information")));
                	}else{
                  	  if(!Factions::isFaction($args[1])){
	                        $sender->sendMessage(str_replace(["&", "{factionName}"], ["§", $args[1]], Loader::getConfiguration("messages")->get("faction_not_exists")));
	                        return;
                        }
                        $homeLocation = Factions::getFactionHomeString($args[1]);
	                    $dtr = Factions::getStrength($args[1]);
	                    $balance = Factions::getBalance($args[1]) === null ? "$0" : "$".Factions::getBalance($args[1]);
	                    $players = Factions::getMaxPlayers($args[1]) === null ? "Error 404 report in discord" : Factions::getMaxPlayers($args[1]);
	                    $maxPlayers = Loader::getDefaultConfig("FactionsConfig")["maxPlayers"];
	                    $onlinePlayers = Factions::getListPlayers($args[1]) === null ? "No members connected" : Factions::getListPlayers($args[1]);
	                    $leader = Factions::getLeader($args[1]) === null ? "Error 404 report in discord" : Factions::getLeader($args[1]).TE::YELLOW."[".TE::GREEN.YamlProvider::getKills(Factions::getLeader($args[1])).TE::YELLOW."]";
	                    $co_leader = Factions::getCoLeader($args[1]) === null ? "There is no co-leader" : Factions::getCoLeader($args[1]).TE::YELLOW."[".TE::GREEN.YamlProvider::getKills(Factions::getLeader($args[1])).TE::YELLOW."]";
	                    $timeRegen = Factions::getFreezeTime($args[1]) === null ? "Null" : Loader::getTimeToString(Factions::getFreezeTime($args[1]));
	                    
	                    $sender->sendMessage(str_replace(["&", "{home}", "{factionName}", "{onlinePlayers}", "{players}", "{maxPlayers}", "{dtr}", "{leader}", "{co_leader}", "{balance}", "{timeRegen}", "%n%"], ["§", $homeLocation, $args[1], $onlinePlayers, $players, $maxPlayers, $dtr, $leader, $co_leader, $balance, $timeRegen, "\n"], Loader::getConfiguration("messages")->get("faction_information")));
	                }
				}
            break;
        }
    }
}

?>