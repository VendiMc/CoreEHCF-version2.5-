<?php

namespace VitalHCF\listeners;

use VitalHCF\Loader;
use VitalHCF\player\Player;

use pocketmine\item\ItemIds;
use pocketmine\event\Listener;
use pocketmine\math\Vector3;
use pocketmine\utils\TextFormat as TE;

use pocketmine\event\player\{PlayerInteractEvent, PlayerMoveEvent};
use pocketmine\event\block\{BlockBreakEvent, BlockPlaceEvent};

use pocketmine\block\{ItemFrame, Door, Fence, FenceGate, Trapdoor, Chest, TrappedChest};
use pocketmine\item\{Bucket, Hoe, Shovel};

class Spawn implements Listener {
	
	/**
	 * Spawn Constructor.
     * @param Loader $plugin
	 */
	public function __construct(Loader $plugin){
		$this->plugin = $plugin;
	}
	
	/**
	 * @param PlayerInteractEvent $event
	 * @return void
	 */
	public function onPlayerInteractEvent(PlayerInteractEvent $event){
		$player = $event->getPlayer();
		$block = $event->getBlock();
		$item = $event->getItem();
		if($player->getLevel() === $this->plugin->getServer()->getDefaultLevel()){
			if($player instanceof Player){
				if($block instanceof ItemFrame||$block instanceof Fence||$block instanceof FenceGate||$block instanceof Door||$block instanceof Trapdoor||$block instanceof Chest||$block instanceof TrappedChest||$item instanceof Bucket||$item instanceof Hoe||$item instanceof Shovel){
					/** @var Vector3|x:|y:|z: */
					$spawn = new Vector3(0, 4, 0);
					if((int)$spawn->distance($event->getBlock()) < 400){
						if($player->isGodMode()){
							$event->setCancelled(false);
						}else{
							$event->setCancelled(true);
						}
					}
				}
			}
		}
		if($player->getLevel()->getName() === Loader::getDefaultConfig("FactionsConfig")["levelEndName"]){
			if($block instanceof ItemFrame||$block instanceof Fence||$block instanceof FenceGate||$block instanceof Door||$block instanceof Trapdoor||$block instanceof Chest||$block instanceof TrappedChest||$item instanceof Bucket||$item instanceof Hoe||$item instanceof Shovel){
				if($player->isGodMode()){
					$event->setCancelled(false);
				}else{
					$event->setCancelled(true);
				}
			}
		}
	}
	
	/**
	 * @param BlockBreakEvent $event
	 * @return void
	 */
	public function onBlockBreak(BlockBreakEvent $event){
		$player = $event->getPlayer();
		if($player->getLevel() === $this->plugin->getServer()->getDefaultLevel()){
			if($player instanceof Player){
				/** @var Vector3|x:|y:|z: */
				$spawn = new Vector3(0, 4, 0);
				if((int)$spawn->distance($event->getBlock()) < 400){
					if($player->isGodMode()){
						$event->setCancelled(false);
					}else{
						$event->setCancelled(true);
					}
				}
			}
		}
		if($player->getLevel()->getName() === Loader::getDefaultConfig("FactionsConfig")["levelEndName"]){
			if($player->isGodMode()){
				$event->setCancelled(false);
			}else{
				$event->setCancelled(true);
			}
		}
	}
	
	/**
	 * @param BlockPlaceEvent $event
	 * @return void
	 */
	public function onBlockPlace(BlockPlaceEvent $event){
		$player = $event->getPlayer();
		if($player->getLevel() === $this->plugin->getServer()->getDefaultLevel()){
			if($player instanceof Player){
				/** @var Vector3|x:|y:|z: */
				$spawn = new Vector3(0, 4, 0);
				if((int)$spawn->distance($event->getBlock()) < 400){
					if($player->isGodMode()){
						$event->setCancelled(false);
					}else{
						$event->setCancelled(true);
					}
				}
			}
		}
		if($player->getLevel()->getName() === Loader::getDefaultConfig("FactionsConfig")["levelEndName"]){
			if($player->isGodMode()){
				$event->setCancelled(false);
			}else{
				$event->setCancelled(true);
			}
		}
	}
	
	/**
	 * @param PlayerMoveEvent $event
	 * @return void
	 */
	public function onPlayerMoveEvent(PlayerMoveEvent $event) : void {
		$player = $event->getPlayer();
		if($player instanceof Player){
			if(!$this->isBorderLimit($player)){
				$player->teleport($this->correctPosition($player));
			}
		}
	}
	
	/**
	 * @param Vector3 $position
	 * @return bool
	 */
	protected function isBorderLimit(Vector3 $position) : bool {
		$border = Loader::getDefaultConfig("FactionsConfig")["BorderLimit"];
		return $position->getFloorX() >= -$border && $position->getFloorX() <= $border && $position->getFloorZ() >= -$border && $position->getFloorZ() <= $border;
	}
	
	/**
	 * @param Vector3 $position
	 * @return Vector3
	 */
	protected function correctPosition(Vector3 $position) : Vector3 {
		$border = Loader::getDefaultConfig("FactionsConfig")["BorderLimit"];
		$radius = 2000;
		
		$x = $position->getFloorX();
		$y = $position->getFloorY();
		$z = $position->getFloorZ();
		
		$xMin = -$border;
		$xMax = $border;
		
		$zMin = -$border;
		$zMax = $border;
		
		if($x <= $xMin){
			$x = $xMin + 4;
		}elseif($x >= $xMax){
			$x = $xMax - 4;
		}
		if($z <= $zMin){
			$z = $zMin + 4;
		}elseif($z >= $zMax){
			$z = $zMax - 4;
		}
		$y = 72;
		return new Vector3($x, $y, $z, $position->getLevel());
	}
}

?>