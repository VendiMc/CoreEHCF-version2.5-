<?php

namespace VitalHCF\listeners;

use VitalHCF\Loader;
use VitalHCF\player\Player;

use VitalHCF\entities\{ThrownEnderPearl, ThrownSplashPotion};
use VitalHCF\Task\EnderPearlTask;

use pocketmine\utils\TextFormat as TE;
use pocketmine\math\Vector3;
use pocketmine\item\{Item, ItemIds};
use pocketmine\event\Listener;
use pocketmine\entity\Entity;
use pocketmine\level\{Position, Level};

use pocketmine\block\{Fence, FenceGate};
use pocketmine\event\player\PlayerInteractEvent;

use pocketmine\nbt\tag\{FloatTag, CompoundTag, DoubleTag, ListTag, ShortTag};

class EnderPearl implements Listener {

    /** @var Loader */
    protected $plugin;

    /**
     * EnderPearl Constructor.
     * @param Loader $plugin
     */
    public function __construct(Loader $plugin){
        $this->plugin = $plugin;
    }

    /**
     * @param PlayerInteractEvent $event
     * @return void
     */
    public function onPlayerInteractEvent(PlayerInteractEvent $event) : void {
        $player = $event->getPlayer();
        $item = $event->getItem();
        $block = $event->getBlock();
        if($item instanceof \VitalHCF\item\SplashPotion){
        	if($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_AIR||$event->getAction() === PlayerInteractEvent::RIGHT_CLICK_BLOCK){
        		$nbt = new CompoundTag("", [
                    new ListTag("Pos", [
                    new DoubleTag("", $player->x),
                    new DoubleTag("", (int)$player->y + $player->getEyeHeight()),
                    new DoubleTag("", $player->z),
                    ]),
                    new ListTag("Motion", [
                    new DoubleTag("", -sin($player->yaw / 180 * M_PI) * cos($player->pitch / 180 * M_PI)),
                    new DoubleTag("", -sin($player->pitch / 180 * M_PI)),
                    new DoubleTag("", cos($player->yaw / 180 * M_PI) * cos($player->pitch / 180 * M_PI)),
                    ]),
                    new ListTag("Rotation", [
                    new FloatTag("", $player->yaw),
                    new FloatTag("", $player->pitch),
                    ]),
                ]);
                $nbt["PotionId"] = new ShortTag("PotionId", $item->getDamage());
                $entity = Entity::createEntity("ThrownSplashpotion", $player->getLevel(), $nbt, $player);
                if($entity instanceof ThrownSplashPotion){
                	$entity->setMotion($entity->getMotion()->multiply(0.5));
                	if($player->isSurvival()){
                        $item->setCount($item->getCount() - 1);
                        $player->getInventory()->setItemInHand(Item::get(Item::AIR));
                    }
                    $entity->spawnToAll();
                }
        	}
        }
        if($item instanceof \VitalHCF\item\EnderPearl && $event->getAction() === PlayerInteractEvent::RIGHT_CLICK_AIR){
            if($player->isEnderPearl()){
                $player->sendTip(str_replace(["&", "{time}"], ["§", Loader::getTimeToString($player->getEnderPearlTime())], Loader::getConfiguration("messages")->get("enderpearl_cooldown")));
                $event->setCancelled(true);
            }else{
                $nbt = new CompoundTag("", [
                    new ListTag("Pos", [
                    new DoubleTag("", $player->x),
                    new DoubleTag("", (int)$player->y + $player->getEyeHeight()),
                    new DoubleTag("", $player->z),
                    ]),
                    new ListTag("Motion", [
                    new DoubleTag("", -sin($player->yaw / 180 * M_PI) * cos($player->pitch / 180 * M_PI)),
                    new DoubleTag("", -sin($player->pitch / 180 * M_PI)),
                    new DoubleTag("", cos($player->yaw / 180 * M_PI) * cos($player->pitch / 180 * M_PI)),
                    ]),
                    new ListTag("Rotation", [
                    new FloatTag("", $player->yaw),
                    new FloatTag("", $player->pitch),
                    ]),
                ]);
                $entity = Entity::createEntity("ThrownEnderpearl", $player->getLevel(), $nbt, $player);
                if($entity instanceof ThrownEnderPearl){
                    $entity->setMotion($entity->getMotion()->multiply(2));
                    if($player->isSurvival()){
                        $item->setCount($item->getCount() - 1);
                        $player->getInventory()->setItemInHand($item->getCount() > 0 ? $item : Item::get(Item::AIR));
                    }
                    $entity->spawnToAll();
                    $player->setEnderPearl(true);
                    $this->plugin->getScheduler()->scheduleRepeatingTask(new EnderPearlTask($player), 20);
                }
            }
        }
        if($item instanceof \VitalHCF\item\EnderPearl && $event->getAction() === PlayerInteractEvent::RIGHT_CLICK_BLOCK){
            if($block instanceof Fence||$block instanceof FenceGate){
                $event->setCancelled(true);
                if($player->isEnderPearl()){
                    $player->sendTip(str_replace(["&", "{time}"], ["§", Loader::getTimeToString($player->getEnderPearlTime())], Loader::getConfiguration("messages")->get("enderpearl_cooldown")));
                    $event->setCancelled(true);
                }else{
                    $nbt = new CompoundTag("", [
                        new ListTag("Pos", [
                        new DoubleTag("", $player->x),
                        new DoubleTag("", (int)$player->y + $player->getEyeHeight()),
                        new DoubleTag("", $player->z),
                        ]),
                        new ListTag("Motion", [
                        new DoubleTag("", -sin($player->yaw / 180 * M_PI) * cos($player->pitch / 180 * M_PI)),
                        new DoubleTag("", -sin($player->pitch / 180 * M_PI)),
                        new DoubleTag("", cos($player->yaw / 180 * M_PI) * cos($player->pitch / 180 * M_PI)),
                        ]),
                        new ListTag("Rotation", [
                        new FloatTag("", $player->yaw),
                        new FloatTag("", $player->pitch),
                        ]),
                    ]);
                    $entity = Entity::createEntity("ThrownEnderpearl", $player->getLevel(), $nbt, $player);
                    if($entity instanceof ThrownEnderPearl){
                        $entity->setMotion($entity->getMotion()->multiply(2));
                        if($player->isSurvival()){
                            $item->setCount($item->getCount() - 1);
                            $player->getInventory()->setItemInHand($item->getCount() > 0 ? $item : Item::get(Item::AIR));
                        }
                        $entity->spawnToAll();
                        $player->setEnderPearl(true);
                        $this->plugin->getScheduler()->scheduleRepeatingTask(new EnderPearlTask($player), 20);
                    }
                }
            }
        }
    }
}

?>